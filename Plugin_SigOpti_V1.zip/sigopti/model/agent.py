# -*- coding: utf-8 -*-
#/***************************************************************************
#
# Sigopti
#                     -------------------
#     begin           : 2018-09-10
#     git sha             : $Format:%H$
#     copyright        : (C) 2018 by CREM Financed through Grant
#                           : Agreement 1705C0046 Agence de l'Environnement
#                           : et de la Maîtrise de l'Energie here after ADEME
#                           : Consortium: Nobatek, FNCCR and CREM
#     email           : info@crem.ch
# ***************************************************************************/

from qgis.core import *
from PyQt5.QtCore import *


from qgis import *


class Agent:

    def __init__(self):

        # inputs from user
        self._name = ""
        self._value = 0



    def get_name(self):
        """

        :return:
        """
        return self._name


    def get_value(self):
        """

        :return:
        """
        return self._value

    def set_name(self, name):
        """
        :param value:
        :return:
        """
        self._name = name


    def set_value(self, value):
        """

        :return:
        """
        self._value = value
