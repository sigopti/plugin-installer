# -*- coding: utf-8 -*-
#/***************************************************************************
#
# Sigopti
#                     -------------------
#     begin           : 2018-09-10
#     git sha             : $Format:%H$
#     copyright        : (C) 2018 by CREM Financed through Grant
#                           : Agreement 1705C0046 Agence de l'Environnement
#                           : et de la Maîtrise de l'Energie here after ADEME
#                           : Consortium: Nobatek, FNCCR and CREM
#     email           : info@crem.ch
# ***************************************************************************/
from PyQt5.QtCore import *
from PyQt5.QtGui import  *
from PyQt5.QtWidgets import QFileDialog


from qgis.core import *
import time

from PyQt5.QtWidgets import (QApplication,
                             QProgressBar)



class UiCommunication:
    """
    Simple dialog that consists of a Progress Bar and a Button.
    Clicking on the button results in the start of a timer and
    updates the progress bar.
    """
    def __init__(self):
        self.prgBar = None

    def remove_former_message(self,message_bar):
        QApplication.processEvents()
        message_bar.clearWidgets()


    def display_information_message(self,message_bar, message):
       QApplication.processEvents()
       message_bar.clearWidgets()
       message_bar.pushMessage("Information", message, level = Qgis.Info, duration=20)
    def display_warning_message(self,message_bar, message):
        message_bar.clearWidgets()
        message_bar.pushMessage("Information", message, level = Qgis.Warning, duration=20)

    def display_error_message(self,message_bar, message):
        message_bar.clearWidgets()
        message_bar.pushMessage("Information", message, level = Qgis.Critical, duration=180)
    def display_simple_success_message(self,message_bar, message):
        message_bar.clearWidgets()
        message_bar.pushMessage("Information", message, level = Qgis.Success, duration=180)


    def display_success_message(self,message_bar,action, message):
        message_bar.clearWidgets()
        message_bar.pushMessage("Succés", "Vous utilisez le fichier "+ message+" en tant que "+action, level = Qgis.Success, duration=180)





    def display_progressbar(self,message_bar,prgBar, inMsg=' Loading...',inMaxStep=100):
        QApplication.processEvents()
        widget = message_bar.createMessage("Veuillez attendre s'il vous plait  ",inMsg)

        print("in display_progressbar")
        self.prgBar = QProgressBar()

        message_bar.clearWidgets()
         # Help to keep UI alive

        widget.layout().addWidget(self.prgBar)


        message_bar.pushWidget(widget, Qgis.Info,inMaxStep)
        #self.prgBar.setMaximum(inMaxStep)
        self.completed = 0
        while self.completed < 100:#QApplication.setOverrideCursor(QtCore.Qt.WaitCursor)
            self.completed += 0.0001
            self.prgBar.setValue(self.completed)
            
    def remove_progress(self,message_bar,inMaxStep=1):
        message_bar.clearWidgets()
       # QApplication.restoreOverrideCursor()
        time.sleep(1)


