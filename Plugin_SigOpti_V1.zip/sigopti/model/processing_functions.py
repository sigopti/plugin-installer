

import sys




from qgis.core import *
sys.path.append('/usr/share/qgis/python/plugins')
import processing
#from Processing import processing

from .helper import *
#for alg in QgsApplication.processingRegistry().algorithms():
 #   print("{}:{} --> {}".format(alg.provider().name(), alg.name(), alg.displayName()))

class Processing_function():

    def __init__(self, ):
        """

        """

        # inputs from user
        self._feedback = QgsProcessingFeedback()
        self._context = QgsProcessingContext()


    def native_buffer(self,input,distance,output_path):
        """

        :param input:
        :param distance:
        :param output_path:
        :return:
        """
        """
            TODO: TO COMPLETE DOCUMENTATION
            """
        output_file = generate_shapefile_name(output_path)
        processing.run("native:buffer", {'INPUT': input,
                                         'DISTANCE': distance,
                                         'SEGMENTS': 10,
                                         'DISSOLVE': True,
                                         'END_CAP_STYLE': 0,
                                         'JOIN_STYLE': 0,
                                         'MITER_LIMIT': 10,
                                         'OUTPUT': output_file }, context=self._context , feedback=self._feedback)

        return output_file

    def native_intersection(self,input,overlay,output_path):
        """

        :param input:
        :param overlay:
        :param output_path:
        :return:
        """
        """
            TODO: TO COMPLETE DOCUMETATION
            """

        output_file = generate_shapefile_name(output_path)
        processing.run('native:intersection', { 'INPUT':input,
                                                'OVERLAY':overlay,
                                                'OUTPUT': output_file}, context=self._context, feedback=self._feedback)

        return output_file


    def qgis_pointsalongline(self,input,output_path):
        """

        :param input:
        :param output_path:
        :return:
        """
        """
            TODO: TO COMPLETE DOCUMENTATION
            """
        output_file = generate_shapefile_name(output_path)
        processing.run('qgis:pointsalonglines', {'DISTANCE':10, # to be added on the constant file
                                             'END_OFFSET':0.0,
                                             'INPUT':input,
                                             'START_OFFSET':0,
                                             'OUTPUT': output_file}, context=self._context, feedback=self._feedback)

        return output_file

    def native_extractbyattribute(self,input,input_conso_min,output_path):
        """
            TODO: TO COMPLETE DOCUMENTATION
            """
        output_file = generate_shapefile_name(output_path)
        processing.run('native:extractbyattribute', {'FIELD':'CALO_MWh','INPUT':input,'OPERATOR':3,'VALUE':input_conso_min,'OUTPUT': output_file}, context=self._context, feedback=self._feedback)

        return output_file


    def qgis_distancetonearesthublinetohub(self,input,hubs,output_path):
        """
            TODO: TO COMPLETE DOCUMENTATION
            """
        output_file = generate_shapefile_name(output_path)



        processing.run('qgis:distancetonearesthublinetohub', {'FIELD':'id','HUBS':hubs,'INPUT':input,'UNIT':0,'OUTPUT': output_file}, context = None, feedback = None)
        return output_file

    def qgis_extendlines(self,input,output_path):
        """
            TODO: TO COMPLETE DOCUMENTATION
            """
        output_file = generate_shapefile_name(output_path)
        processing.run('qgis:extendlines', {'END_DISTANCE':0.2,
                                            'INPUT':input,
                                            'START_DISTANCE':0, #TODO where this value come from
                                            'OUTPUT': output_file}
                       , context=self._context, feedback=self._feedback)
        return output_file

    def native_splitwithlines(self,input,lines,output_path):
        """
            TODO: TO COMPLETE DOCUMENTATION
            """
        output_file = generate_shapefile_name(output_path)
        processing.run('native:splitwithlines', {'INPUT':input,'LINES':lines, 'OUTPUT': output_file},
                       context=self._context, feedback=self._feedback)
        return output_file
    def native_explodelines(self,input,output_path):
        """
            TODO: TO COMPLETE DOCUMENTATION
            """
        output_file = generate_shapefile_name(output_path)
        processing.run('native:explodelines', {'INPUT':input,'OUTPUT': output_file}, context=self._context, feedback=self._feedback)
        return output_file



    def native_lineintersections(self,input,intersect,output_path):
        """
            TODO: TO COMPLETE DOCUMENTATION
            """
        output_file = generate_shapefile_name(output_path)
        processing.run('native:lineintersections', {'INPUT':input,
                                                    'INTERSECT':intersect,
                                                    'OUTPUT': output_file}, context=self._context, feedback=self._feedback)
        return output_file
    def native_multiparttosingleparts(self,input,output_path):
        output_file = generate_shapefile_name(output_path)
        processing.run('native:multiparttosingleparts', {'INPUT':input,
                                                         'OUTPUT': output_file}, context=self._context, feedback=self._feedback)
        return output_file
