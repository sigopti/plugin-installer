# -*- coding: utf-8 -*-
#/***************************************************************************
#
# Sigopti
#                     -------------------
#     begin           : 2018-09-10
#     git sha             : $Format:%H$
#     copyright        : (C) 2018 by CREM Financed through Grant
#                           : Agreement 1705C0046 Agence de l'Environnement
#                           : et de la Maîtrise de l'Energie here after ADEME
#                           : Consortium: Nobatek, FNCCR and CREM
#     email           : info@crem.ch
# ***************************************************************************/

from qgis.core import *
from PyQt5.QtCore import *
import json
import copy
from .saver import *
from .agent import *
from .helper import from_dict_to_unique_array, refine_array,retrieve_content_file,get_value_from_selected_name, get_production_source_from_code, write_to_file_with_path
class Optimisation:

    def __init__(self):

        # inputs from user


        self._configuration_list = None
        self._source_main_heats = [{"name":"Chaudière à bois","code":"biomasse"},{"name":"Chaudière à fioul","code":"fioul"}, {"name":"Chaudière à gaz","code":"gaz"},{"name":"Pompe à chaleur","code":"pac"},{"name":"Usine d'incinération des ordures ménagère","code":"uiom"}]
        self._source_appoint_heats = [{"name":"Chaudière à fioul","code":"fioul"}, {"name":"Chaudière à gaz","code":"gaz"}]
        self._agent_energie_1 = Agent()
        self._config_path = None
        self._agent_energie_2 = Agent()
        self._agent_energie_1.set_name(self._source_main_heats[0])
        self._agent_energie_2.set_name(self._source_appoint_heats[0])
        self._agent_energie_1.set_value(60)
        self._agent_energie_2.set_value(40)
        self._config_file_json = {}
        self.update()


    def set_optimistation_path(self,index):
        """

        :param index:
        :return:
        """

        if index > 0:
            index = index - 1
            list = copy.deepcopy(self._configuration_list)
            del list[0]
            self._config_path = from_dict_to_unique_array(list,'path')[index]
        else:
            self._config_path = None

    def get_current_config_path(self):
        """
        : return current path
        """
        return self._config_path

    def is_config_set_up(self):
        config_ready = False
        if self._config_path is not None:
            config_ready = True
        return config_ready


    def get_configuration_list_name(self):
        """
        :return: list of agent
        """
        self.update()
        return from_dict_to_unique_array(self._configuration_list,'name')
    def get_configuration_from_path(self):
        """

        :return: list of agent
        """
        return from_dict_to_unique_array(self._configuration_list,'path')

    def update(self):
        """

        :return:
        """
        saver = Saver()
        configuration_list = saver.get_value_with_key('network_configuration_list',[{"name":"title","path":"no_path"} ])
        configuration_list = refine_array(configuration_list,"no_path")
        saver.save_value_with_key('network_configuration_list',configuration_list)

        #
        seen = set()
        new_l = []
        for d in configuration_list:
            t = tuple(d.items())
            if t not in seen:
                seen.add(t)
                new_l.append(d)



        self._configuration_list = new_l


    def get_configuration_path_from_name(self,name):
        """

        :return: list of agent
        """
        return from_dict_to_unique_array(self._configuration_list,'name')

    def get_source_main_heats(self):
        """

        :return: list of main heats sources
        """

        return from_dict_to_unique_array(self._source_main_heats,'name')

    def get_source_appoint_heats(self):
        """

        :return: list of main apoint sources
        """
        return from_dict_to_unique_array(self._source_appoint_heats,'name')


    def get_agent_energie_1_value(self):
        """

        :return: list of agent
        """
        return self._agent_energie_1.get_value()



    def get_agent_energie_2_value(self):
        """

        :return: list of agent
        """
        return self._agent_energie_2.get_value()

    def set_agent_energie_1_value(self, value):
        """

        :param value:
        :return:
        """
        self._agent_energie_1.set_value(value)


    def set_agent_energie_2_value(self,value):
        """

        :param value:
        :return:
        """
        self._agent_energie_2.set_value(value)

    def set_agent_source_appoint_heat_name(self, index):
        """

        :param name:
        :return:
        """

        code = get_value_from_selected_name(index,self._source_appoint_heats)
        return get_production_source_from_code(code)




    def get_agent_energie_1_name(self):
        """

        :param name:
        :return:
        """

        return self._agent_energie_1.get_name()


    def get_agent_energie_2_name(self):
        """

        :param name:
        :return:
        """

        return self._agent_energie_2.get_name()






    def set_agent_source_main_heat_name(self, index):
        """

        :param name:
        :return:
        """

        code = get_value_from_selected_name(index,self._source_main_heats)
        return get_production_source_from_code(code)



    def run_optimisation(self,table_main,table_seconde,table_others,coverage_rate):

        technologies =  {
            "k1": {
                "efficiency":  float(table_main.item(4,1).text())/100, #rendement de technologie
                "t_out_max": float(table_main.item(0,1).text()), #Température de départ maximale
                "t_in_min": float(table_main.item(1,1).text()), #Température de retour minimal
                "production_unitary_cost": float(table_main.item(2,1).text()), # Coût unitaire de la chaudière
                "energy_unitary_cost": float(table_main.item(3,1).text()),#Coût unitaire de l'énergie finale
                "energy_cost_inflation_rate":float(table_main.item(5,1).text())/100,#nflation de l'énergie liée à la technologie
                "coverage_rate":float(coverage_rate)/100


            },
            "k2": {
                "efficiency":  float(table_seconde.item(4,1).text())/100,
                "t_out_max":float( table_seconde.item(0,1).text()),
                "t_in_min": float(table_seconde.item(1,1).text()),
                "production_unitary_cost":float( table_seconde.item(2,1).text()),
                "energy_unitary_cost": float(table_seconde.item(3,1).text()),
                "energy_cost_inflation_rate":float(table_seconde.item(5,1).text())/100,
                #"coverage_rate":float(coverage_rate)/100
            },


        }
        import json


        parameters =  {
            "heat_loss_rate": float(table_others.item(0,1).text())/100, # taux de pertes thermiques
            "simultaneity_ratio": float(table_others.item(1,1).text())/100, # taux de pertes thermiques
           # "speed_min": float(table_others.item(5,1).text()),# borne vitesse min, 0.1m/s d'après Techniques de l'Ingénieur
            "speed_max": float(table_others.item(4,1).text()),# borne vitesse max, 3m/s d'après Techniques de l'Ingénieur
            #"diameter_int_min": float(table_others.item(4,1).text()),# diamètre interieur min du tuyau (m)
            "diameter_int_max": float(table_others.item(3,1).text()),# diamètre interieur max du tuyau (m)
            "operation_time": float(table_others.item(6,1).text()),  # durée de fonctionnement annuelle du RCU
            "depreciation_period": float(table_others.item(7,1).text()),# duree d'amortissement
            "discout_rate": float(table_others.item(5,1).text())/100,# taux d'actualisation pour le calcul de l'annuite des investissements initiaux
            "trench_unit_cost": float(table_others.item(2,1).text()),# coût unitaire de tranchee aller-retour
            "pump_energy_ratio_cost": float(table_others.item(8,1).text())/100    # ratio du coût de pompage/coût global



        }



        if self._config_path is not None:
            sources = retrieve_content_file(self._config_path)
            consumption = sources[0][0]['nodes']
            consumption.pop(0)
            for element in consumption:
                del element['kWh']
            links =  sources[0][0]['links']
            sources_0 = links[0]['source'][0]
            sources_1 = links[0]['source'][1]
            payload = { 'nodes': {
                                    'production': [
                                        # P1
                                        {
                                            'id': [sources_0, sources_1],
                                            'technologies': technologies,
                                        },
                                    ],
                                    'consumption':consumption,},
                                'links': links,
                                'parameters': parameters
                            }


            return payload

    def retrieve_content_file_to_dict(self,ui_communication,iface):

        if self._config_path is not None:
            sources = retrieve_content_file(self._config_path)
            try:
                result = sources[0][0]['intermediate_result']
                return result
            except:
                ui_communication.display_error_message(iface, "le fichier de configuration selectionné n'a pas de réseaux complet générée.")
                return



    def write_to_file_with_path(self,content):
        name_file,path = write_to_file_with_path(self._config_path, content)

        return name_file,path


    def retrieve_content_file_to_dict_optim(self,ui_communication,iface):

        if self._config_path is not None:
            sources = retrieve_content_file(self._config_path)
            try:
                optim_result = sources[0][0]['optim_result']

                return optim_result
            except:
                ui_communication.display_error_message(iface, "le fichier de configuration selectionné n'a pas d'optimisation généréé.")
                return






