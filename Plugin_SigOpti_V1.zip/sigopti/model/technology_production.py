# -*- coding: utf-8 -*-
#/***************************************************************************
#
# Sigopti
#                     -------------------
#     begin           : 2018-09-10
#     git sha             : $Format:%H$
#     copyright        : (C) 2018 by CREM Financed through Grant
#                           : Agreement 1705C0046 Agence de l'Environnement
#                           : et de la Maîtrise de l'Energie here after ADEME
#                           : Consortium: Nobatek, FNCCR and CREM
#     email           : info@crem.ch
# ***************************************************************************/
from qgis.core import *
from PyQt5.QtCore import *


from qgis import *


class TechnologyProduction:

    def __init__(self,efficiency,t_out_max,t_in_min,production_unitary_cost,energy_unitary_cost, energy_cost_inflation_rate):

        # inputs from user
        self._source_production = efficiency
        self._efficiency = efficiency
        self._t_out_max = t_out_max
        self._t_in_min = t_in_min
        self._production_unitary_cost = production_unitary_cost
        self._energy_unitary_cost= energy_unitary_cost
        self._energy_cost_inflation_rate= energy_cost_inflation_rate
        self._energy_cost_inflation_rate= energy_cost_inflation_rate
        self._parameter_name= energy_cost_inflation_rate
        self._unit = energy_cost_inflation_rate




    def get_efficiency(self):
        """

        :return:
        """
        return self._efficiency

    def set_efficiency(self, efficiency):
        """
        :param value:
        :return:
        """
        self._efficiency = efficiency

    def get_t_out_max(self):
        """

        :return:
        """
        return self._t_out_max




    def set__t_out_max(self, value):
        """

        :return:
        """
        self._value = value
