#!/usr/bin/python3
# -*- coding: utf-8 -*-
#/***************************************************************************
#
# Sigopti
#                     -------------------
#     begin           : 2018-09-10
#     git sha             : $Format:%H$
#     copyright        : (C) 2018 by CREM Financed through Grant
#                           : Agreement 1705C0046 Agence de l'Environnement
#                           : et de la Maîtrise de l'Energie here after ADEME
#                           : Consortium: Nobatek, FNCCR and CREM
#     email           : info@crem.ch
# ***************************************************************************/

'''
QNetworkAccessManager in PyQt

In this example we post data to a web page.

Author: Jan Bodnar
Website: zetcode.com
Last edited: September 2017
'''


import json
import sys
from PyQt5.QtCore import QObject, QUrl, QByteArray
from PyQt5.QtNetwork import QNetworkAccessManager,QNetworkRequest

class Networking(QObject):

    def __init__(self):
        QObject.__init__(self)
        self.onSuccess = None
        self.onFailed = None

        self.m_netReply = None


    def post(self,httpUrl,sendData,m_netAccessManager):

        if self.m_netReply is not None:
            self.m_netReply.disconnect()


       # self.onJsonParams = jsonParams

        req = QNetworkRequest(QUrl(httpUrl))
        req.setHeader(QNetworkRequest.ContentTypeHeader,"application/x-www-form-urlencoded")

        senda = QByteArray()
        senda.append(sendData)

        m_netReply = m_netAccessManager.post(req,senda)

        return m_netReply



    def convertDict(self,dict):
        str = ""
        index = 1
        for key,value in dict.items():
            if index == len(dict):
                str = str + '%s%s%s' % (key, '=', value)
            else:
                str = str + '%s%s%s%s' % (key, '=', value,'&')

            index += 1

        return str


