# -*- coding: utf-8 -*-
#/***************************************************************************
#
# Sigopti
#                     -------------------
#     begin           : 2018-09-10
#     git sha             : $Format:%H$
#     copyright        : (C) 2018 by CREM Financed through Grant
#                           : Agreement 1705C0046 Agence de l'Environnement
#                           : et de la Maîtrise de l'Energie here after ADEME
#                           : Consortium: Nobatek, FNCCR and CREM
#     email           : info@crem.ch
# ***************************************************************************/

from qgis.core import QgsVectorLayer
from qgis.core import *

import networkx as nx
class Layer():

    def __init__(self,path,name,type ):
        """
        initialization of the class layer with is support to store information about the layer
        :param path: physical path of the layer
        :param name: name of the layer
        :param type: type of the layer, can be vector "ogr" or raster
        ..
        """

        layer = QgsVectorLayer(path, name,'ogr')
        self._path = path
        self._name = name
        self._type = type
        self._layer = layer
        if not layer.isValid():
            print ("the path {} is unable to load a shapefile".format(path))
            raise Exception("the path {} is unable to load a shapefile".format(path))


    def get_name(self):
        return self._name

    def set_name(self, name):
        self._name = name
    def get_crs(self):
        return self._layer.crs()
    def get_path(self):
        return self._path

    def set_path(self, path):
        self._path = path

    def get_layer(self):

        return self._layer

    def check_attribute_kwh(self):
        conso_sel = nx.read_shp(self.get_path())
        check = False
        try:
            total_conso_sel = 0
            for (n, attr) in conso_sel.nodes.items():
                total_conso_sel = total_conso_sel + attr["kWh"]
            check = True
        except:
            check = False
        return check

    def display(self,iface):
        """
        this method will display is layer
        :param iface: need iface to display the data
        :return: nothing
        """

        layer = QgsVectorLayer(self._path, self._name,self._type)
        if not layer.isValid():
            iface.messageBar().pushCritical("Failed to load:", self._name)
            return
        iface.addVectorLayer(self._path, "", self._type)

