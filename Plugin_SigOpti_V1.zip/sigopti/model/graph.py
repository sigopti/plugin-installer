# -*- coding: utf-8 -*-
#/***************************************************************************
#
# Sigopti
#                     -------------------
#     begin           : 2018-09-10
#     git sha             : $Format:%H$
#     copyright        : (C) 2018 by CREM Financed through Grant
#                           : Agreement 1705C0046 Agence de l'Environnement
#                           : et de la Maîtrise de l'Energie here after ADEME
#                           : Consortium: Nobatek, FNCCR and CREM
#     email           : info@crem.ch
# ***************************************************************************/
from qgis.core import *

import networkx as nx

import matplotlib.pylab as plt
import numpy as np
from .helper import *

class Graph():

    def __init__(self,feeder_seg, secondaire, conso_sel,sources ):
        """
        initialization of the class Graph with is support to store information about the Graph
        :param path: physical path of the layer
        :param name: name of the layer
        :param type: type of the layer, can be vector "ogr" or raster ..
        """
        self._feeder_seg = nx.read_shp(feeder_seg)
        self._secondaire = nx.read_shp(secondaire)
        self._conso_sel = nx.read_shp(conso_sel)
        self._sources = nx.read_shp(sources)
        #consommation citation
        self._consumption_tot , self._power_tot= self.calculate_consumption_power()
        self._longueur = None
        self._plot_h = None
        self._h_dir = None
        self._h_dir_final = None
        self._h_dir_final = None

    #consommation citation
    def calculate_consumption_power(self):
        """
          calculate the consumption from the sel
          :return:
          """
        total_conso_sel = 0
        total_power_sel = 0
        for (n, attr) in self._conso_sel.nodes.items():
            total_conso_sel = total_conso_sel + attr["kWh"]
            total_power_sel = total_power_sel + attr["kW"]

        return float(total_conso_sel),float(total_power_sel)

    #consommation citation
    def get_consumption_tot(self):
        """
       getter to retrieve the consumption
       :return:
       """
        return self._consumption_tot

    def get_power_tot(self):
        """
       getter to retrieve the consumption
       :return:
       """
        return self._power_tot
    def get_feeder_seg (self):
        """
        getter to retrieve the feeder
        :return:
        """
        return self._feeder_seg


    def get_sources (self):
        """
        getter to retrieve the feeder
        :return:
        """
        return self._sources

    def get_longueur (self):
        """
        getter to retrieve the feeder
        :return:
        """
        return self._longueur

    def set_feeder_seg (self, feeder_seg ):
        """
        method to set the feeder
        :param feeder_seg:
        :return:
        """
        self._feeder_seg  = feeder_seg

    def get_secondaire(self):
        return self._secondaire

    def set_secondaire(self, secondaire):
        self._secondaire = secondaire

    def get_conso_sel(self):
        return self._conso_sel

    def set_path(self, conso_sel):
        self._conso_sel = conso_sel

    def round_coordinate(self):

        self._feeder_seg = nx.relabel_nodes(self._feeder_seg,{n:(round(n[0]), round(n[1])) for n in self._feeder_seg.nodes()})
        self._secondaire  = nx.relabel_nodes( self._secondaire ,{n:(round(n[0]), round(n[1])) for n in  self._secondaire .nodes()})
        self._conso_sel = nx.relabel_nodes(self._conso_sel,{n:(round(n[0]), round(n[1])) for n in self._conso_sel.nodes()})
        self._sources = nx.relabel_nodes(self._sources,{n:(round(n[0]), round(n[1])) for n in self._sources.nodes()})

        self.clean_attributes()



    def clean_attributes(self):
        #Clear attributes
        #--- Clean Feeder_seg and Secondaire edges
        for (n1,n2,attr) in self._feeder_seg.edges(data=True):
            attr.clear()
        for (n1,n2,attr) in self._secondaire.edges(data=True):
            attr.clear()


    def connexe_graph_creation(self):
        #Connexe Graph creation
        G_dir = nx.compose(self._feeder_seg, self._secondaire)
        G_undir = G_dir.to_undirected()
        #Set Consumptions

        self._G_undir = G_undir

        return self._G_undir


    def process_graph(self):
        self.round_coordinate()
        G_undir = self.connexe_graph_creation()
        h_undir = self.define_graph_config(G_undir)
        self._h_dir = self.set_direction(h_undir)
        self.set_initial_nodes_values(self._h_dir )
        return self._h_dir



    def export_unidirected_graph(self,path, iface):
        keys= {x: str(x) for x in self._G_undir.nodes()}
        G_undir_str = nx.relabel_nodes(self._G_undir,keys)
        gml_file =  generate_gml_name(path)
        nx.write_gml(G_undir_str, gml_file, stringizer=None)

    def export_directed_graph(self,path, iface):
        keys= {x: str(x) for x in self._h_dir.nodes()}
        h_dir_str = nx.relabel_nodes(self._h_dir,keys)
        gml_file =  generate_gml_name(path)
        nx.write_gml(h_dir_str, gml_file, stringizer=None)

    def generate_payload_for_optimiser(self,h_dir_final):

        self.set_payloads(retrieveJson(h_dir_final))



    def define_graph_config(self,g_undir):

        #--- Creation of the dictionnary for the different configurations (different sources) of one feeder ---
        #H_undir.clear()
        h_undir = {s: g_undir.copy(as_view=False) for s in self._sources.nodes.keys()}
        H_undir_length = {s:0  for s in self._sources.nodes.keys()}

        #self.plot_network(g_undir)


        #--- Add the corresponding source to the feeder.
        for (s, attr) in self._sources.nodes.items():

            #--- find closest node to the source --- Question ? only on feeder nodes ?
            Dist_to_source_dict = {n : np.linalg.norm(np.array(n)-np.array(s)) for n in g_undir.nodes.keys()}
            Closest_graph_node = min(Dist_to_source_dict.items(), key=lambda n: n[1])[0]
            h_undir[s].add_edge(s, Closest_graph_node)


            #--- set edges length ---
            Edge_Length_dict = {(x,y) : int(round(np.linalg.norm(np.array(x)-np.array(y)))) for (x,y)  in h_undir[s].edges.keys()}
            for (e, dist) in Edge_Length_dict.items():
                if dist<1:
                    Edge_Length_dict[e]=1
            nx.set_edge_attributes(h_undir[s],Edge_Length_dict, name="length")
            self._longueur = sum(Edge_Length_dict.values())


        return h_undir

    def plot_network(self,graph):
        import matplotlib.pyplot as plt
        position_dict = {x: x for x in graph.nodes.keys()} #dict comprehension
        width = 15
        height = 10
        fig = plt.figure(figsize=(width, height))
        nx.draw_networkx(graph, \
                         pos=position_dict, \
                         node_size=100, \
                         with_labels=True, \
                         width=3,
                         edge_color ='silver',
                         #linewidth=1.5, \
                         font_size =7, \
                         node_color='y')
        fig.suptitle('Plot Network', fontsize=20)
        plt.show(block=False)

    def set_direction(self,h_undir):
        h_dir = {s: nx.DiGraph() for s in h_undir.keys()}

        for s in h_undir.keys():
            #--- Find the path, from source to each nodes, and the cumulated distance to source ---
            shortest_paths = nx.single_source_shortest_path(h_undir[s], s)
            Dist_to_source = nx.shortest_path_length(h_undir[s], s, weight="length")

            #--- Set direction by the shortest path ---
            for n, path_n in shortest_paths.items():
                for i in range(1, len(path_n)):
                    h_dir[s].add_edge(path_n[i-1], path_n[i])

            #--- set for each nodes the cumulated distance to source ---
            #nx.set_node_attributes(h_dir[s],Dist_to_source, name="Dist_to_source")

            #--- set edge length ---
            Dist_dict = {(x,y) : int(round(np.linalg.norm(np.array(x)-np.array(y)))) for (x,y)  in h_dir[s].edges.keys()}
            for (e, dist) in Dist_dict.items():
                if dist<1:
                    Dist_dict[e]=1
            nx.set_edge_attributes(h_dir[s],Dist_dict, name="length")

        return h_dir


    def set_initial_nodes_values(self,h_dir):

        for s in h_dir.keys():
            #--- set Type to "Source" for the given nodes ---
            #--- set Type to "Source" for the given nodes ---
            #h_dir[s].add_node(s, Type="Source")
            #--- Initialize the kWh attribute to 0 ---
            nx.set_node_attributes(h_dir[s], 0, "kWh")
            nx.set_node_attributes(h_dir[s], 0, "kW")
            nx.set_node_attributes(h_dir[s], 60, "t_in")
            nx.set_node_attributes(h_dir[s], 80, "t_out")
            #--- recover and convert to kWh, the consumption in the Conso_sel graph ---

            #--- set the updated values for the nodes consumption in kWh ---
            val = nx.get_node_attributes(self._conso_sel,'kWh')
            nx.set_node_attributes(h_dir[s],val, name='kWh')
            val = nx.   get_node_attributes(self._conso_sel,'kW')
            nx.set_node_attributes(h_dir[s],val, name="kW")
            val = nx.get_node_attributes(self._conso_sel,'t_in')
            nx.set_node_attributes(h_dir[s],val, name="t_in")
            val = nx.get_node_attributes(self._conso_sel,'t_out')
            nx.set_node_attributes(h_dir[s],val, name="t_out")
        #self.aggregate_values()
        self._plot_h = h_dir
        return h_dir



    def aggregate_values(self,):
        self._payloads = []
        for s in self._plot_h.keys():
            Energy_tot_dict = {n: round(sum([self._plot_h[s].nodes[m]["kWh"] for m in nx.descendants(self._plot_h[s], n)] + \
                                            [self._plot_h[s].nodes[n]["kWh"]])) for n in self._plot_h[s].nodes()}
            #nx.set_node_attributes(self._plot_h[s], Energy_tot_dict, name="tot_kWh")
        self._h_dir_final = self._plot_h

        return self._plot_h


    def plot_kWh_Dist(self,h):

        for s in h.keys():
            attr_list = list(self._plot_h[s].nodes.values())
            DF = pd.DataFrame(attr_list)
            DF.sort_values(by="Dist_to_source",ascending=True, inplace=True)
            DF["cumsum_kWh"]=DF["kWh"].cumsum()
            plt.plot(DF["Dist_to_source"],DF["cumsum_kWh"], label=str(s))
            plt.legend()
        plt.grid()
        #plt.show()



    def comparison_graph(self):
        pass
        #self.plot_kWh_Dist(self._plot_h)












