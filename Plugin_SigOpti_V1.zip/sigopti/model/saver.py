# -*- coding: utf-8 -*-
#/***************************************************************************
#
# Sigopti
#                     -------------------
#     begin           : 2018-09-10
#     git sha             : $Format:%H$
#     copyright        : (C) 2018 by CREM Financed through Grant
#                           : Agreement 1705C0046 Agence de l'Environnement
#                           : et de la Maîtrise de l'Energie here after ADEME
#                           : Consortium: Nobatek, FNCCR and CREM
#     email           : info@crem.ch
# ***************************************************************************/
from PyQt5.QtCore import *
from PyQt5.QtGui import  *



from qgis.core import *
from qgis import *

from qgis.gui import *




class Saver():

    def __init__(self,):
        """
        initialization of the class Graph with is support to store information about the Graph
        :param path: physical path of the layer
        :param name: name of the layer
        :param type: type of the layer, can be vector "ogr" or raster ..
        """
        self._project  = QgsSettings()

    def save_value_with_key(self, key, value):
        """
        save data to qgis memory
        :param key:
        :param value:
        :return:
        """
        self._project.setValue( key,value )

    def get_value_with_key(self, key, default):
        """

        :param key:
        :return:
        """
        return self._project.value(key, default)

    def delete_all_values(self):
        """

        :param key:
        :return:
        """
        return self._project.clear()
