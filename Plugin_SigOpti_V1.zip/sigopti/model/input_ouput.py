# -*- coding: utf-8 -*-
#/***************************************************************************
#
# Sigopti
#                     -------------------
#     begin           : 2018-09-10
#     git sha             : $Format:%H$
#     copyright        : (C) 2018 by CREM Financed through Grant
#                           : Agreement 1705C0046 Agence de l'Environnement
#                           : et de la Maîtrise de l'Energie here after ADEME
#                           : Consortium: Nobatek, FNCCR and CREM
#     email           : info@crem.ch
# ***************************************************************************/
from .saver import *

from .layer import *
from PyQt5.QtWidgets import QFileDialog


def select_input_shp(dlg,title_dialog,key_save_name):
    filter = "ESRI Shapefile (*.shp)"
    saver = Saver()
    filename = QFileDialog.getOpenFileName(dlg,title_dialog ,saver.get_value_with_key(key_save_name,""), filter)
    working_well = False
    if filename is not None and  filename[0]:
        working_well = True
        saver.save_value_with_key(key_save_name,filename[0])
        return filename[0],working_well


def load_shapefiles( shp_path ,name,iface,action_name,action_text):
    """
    :param shp_path: physical path to the shapefile
    :return:
    """
    layer = Layer(shp_path, name, 'ogr')

    saver = Saver()
    feeder_saved = saver.get_value_with_key(name,"")
    action_name.setText(action_text)
    import os
    dir_path = os.path.dirname(os.path.realpath(__file__)).replace('model','styles')
    print('dir_path', dir_path)
    pathqml = dir_path + '/' + str(name) + '.qml'
    layer.get_layer().loadNamedStyle(pathqml)
    QgsProject.instance().addMapLayer(layer.get_layer(),True)

    return layer

def load_simple_shapefile( shp_path ,name):
    """
    :param shp_path: physical path to the shapefile
    :return:
    """
    layer = Layer(shp_path, name, 'ogr')
    saver = Saver()
    feeder_saved = saver.get_value_with_key(name,"")
    import os
    dir_path = os.path.dirname(os.path.realpath(__file__)).replace('model','styles')
    print('dir_path', dir_path)
    pathqml = dir_path + '/' + str(name) + '.qml'
    layer.get_layer().loadNamedStyle(pathqml)
    QgsProject.instance().addMapLayer(layer.get_layer(),True)
    return layer



    return layer
def select_output_configuration(dlg):
    saver = Saver()
    dir = QFileDialog.getOpenFileName(None, 'Selectionner une configuration optimiser',"", "Fichier JSON (*.json)")
    if dir is not None and  dir:
        saver.save_value_with_key('last_path_configuration',dir[0])
    return dir

