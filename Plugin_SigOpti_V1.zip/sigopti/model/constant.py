# -*- coding: utf-8 -*-
#/***************************************************************************
#
# Sigopti
#                     -------------------
#     begin           : 2018-09-10
#     git sha             : $Format:%H$
#     copyright        : (C) 2018 by CREM Financed through Grant
#                           : Agreement 1705C0046 Agence de l'Environnement
#                           : et de la Maîtrise de l'Energie here after ADEME
#                           : Consortium: Nobatek, FNCCR and CREM
#     email           : info@crem.ch
# ***************************************************************************/

DEV_SERVER_URL = "https://pyodhean.nobatek.com/api/v0/"


PRODUCTION_SOURCE_LIST = {

     "fioul":{
         'efficiency': {'name':u'rendement de technologie (%)','value':'90','unit':'%'},
         't_out_max': {'name':u'Température de départ maximale','value':'100','unit':u'°C'},
         't_in_min':  {'name':u'Température d'
                              u'e retour minimale','value':'30','unit':u'°C'},
         'production_unitary_cost': {'name':u' Coût unitaire de la chaudière','value':'1000','unit':u'€/kW'},
         'energy_unitary_cost':{'name':u"Coût unitaire de l'énergie finale",'value':'0.1','unit':u'€/kWh'},
         'energy_cost_inflation_rate': {'name':u"inflation de l'énergie liée à la technologie",'value':'6','unit':u'%'}

     },
    "biomasse":{
        'efficiency': {'name':u'rendement de technologie (%)','value':'80','unit':'%'},
        't_out_max': {'name':u'Température de départ maximale','value':'100','unit':u'°C'},
        't_in_min':  {'name':u'Température d'
                             u'e retour minimale','value':'30','unit':u'°C'},
        'production_unitary_cost': {'name':u' Coût unitaire de la chaudière','value':'800','unit':u'€/kW'},
        'energy_unitary_cost':{'name':u"Coût unitaire de l'énergie finale",'value':'0.03','unit':u'€/kW'},
        'energy_cost_inflation_rate': {'name':u"inflation de l'énergie liée à la technologie",'value':'1.5','unit':u'%'}

    },
    "gaz":{
        'efficiency': {'name':u'rendement de technologie (%)','value':'90','unit':'%'},
        't_out_max': {'name':u'Température de départ maximale','value':'100','unit':u'°C'},
        't_in_min':  {'name':u'Température d'
                             u'e retour minimale','value':'30','unit':u'°C'},
        'production_unitary_cost': {'name':u' Coût unitaire de la chaudière','value':'1000','unit':u'€/kW'},
        'energy_unitary_cost':{'name':u"Coût unitaire de l'énergie finale",'value':'0.08','unit':u'€/kW'},
        'energy_cost_inflation_rate': {'name':u"inflation de l'énergie liée à la technologie",'value':'4','unit':u'%'}

    },

    "pac":{
        'efficiency': {'name':u'rendement de technologie (%)','value':'30','unit':'%'},
        't_out_max': {'name':u'Température de départ maximale','value':'100','unit':u'°C'},
        't_in_min':  {'name':u'Température d'
                             u'e retour minimale','value':'30','unit':u'°C'},
        'production_unitary_cost': {'name':u' Coût unitaire de la chaudière','value':'3000','unit':u'€/kW'},
        'energy_unitary_cost':{'name':u"Coût unitaire de l'énergie finale",'value':'0.14','unit':u'€/kW'},
        'energy_cost_inflation_rate': {'name':u"inflation de l'énergie liée à la technologie",'value':'4','unit':u'%'}

    },

    "uiom":{
        'efficiency': {'name':u'rendement de technologie (%)','value':'50','unit':'%'},
        't_out_max': {'name':u'Température de départ maximale','value':'100','unit':u'°C'},
        't_in_min':  {'name':u'Température d'
                             u'e retour minimale','value':'30','unit':u'°C'},
        'production_unitary_cost': {'name':u' Coût unitaire de la chaudière','value':'200','unit':u'€/kW'},
        'energy_unitary_cost':{'name':u"Coût unitaire de l'énergie finale",'value':'0.02','unit':u'€/kW'},
        'energy_cost_inflation_rate': {'name':u"inflation de l'énergie liée à la technologie",'value':'2','unit':u'%'}

    },




}

HOST = 'https://pyodhean.nobatek.com/api/v0/'




MAIN_RESULT_LIST =  [{'name':u'Consommation totale raccordée','value':'','unit':'MWh','key':"consumption_tot_mwh"},
            {'name':u'Puissance totale raccordée','value':'','unit':'MW','key':"power_tot_mw"},
            {'name':u'Longueur totale de réseau (aller-simple)','value':'','unit':'ml','key':"length"},
            {'name':u'Densité thermique','value':'','unit':'MWh/ml','key':"thermal_density"},
            {'name':u'Densité de puissance','value':'','unit':'kW/ml','key':"power_density"}]


SECONDE_RESULT_LIST =  [{'name':u'Coût global','value':'','unit':'M €'},
                     {'name':u'Coût de la chaleur produite','value':'','unit':'M €'},
                     {'name':u"Coût de la création de l'unité de production",'value':'','unit':'M €'},
                     {'name':u'Coût des échangeurs en sous-station','value':'','unit':'M €'},
                     {'name':u'Coût global des canalisations (tranchée +conduites)','value':'','unit':'M €'},
                        {'name':u' → Coût de tranchée','value':'','unit':'M €'},
                        {'name':u' → Coût de conduites','value':'','unit':'M €'}, {'name':u'Coût de pompage','value':'','unit':'M €'}]

OPTIM_RESULT_LIST =  [{'name':u"Coût global sur la durée d'amortissement",'value':'','unit':'M €'},
                        {'name':u"Coût global de l'énergie",'value':'','unit':'€/MWh'},
                        {'name':u"Coût global par mètre linéaire",'value':'','unit':'k€/ml'}]

SETUP_UP_COST_RESULT_LIST =  [{'name':u"Coût de la création de l'unité de production",'value':'','unit':'M €'},
                        {'name':u'Coût des échangeurs en sous-station','value':'','unit':'M €'},
                        {'name':u'Coût global des canalisations (tranchée +conduites)','value':'','unit':'M €'},
                        {'name':u' → Coût de tranchée','value':'','unit':'M €'},
                        {'name':u' → Coût de conduites','value':'','unit':'M €'},
                           {'name':u'Total','value':'','unit':'M €'}]

WORKING_COST_RESULT_LIST =  [{'name':u'Coût de la chaleur produite','value':'','unit':'M €'},
                         {'name':u'Coût de pompage','value':'','unit':'M €'},
                             {'name':u'Total','value':'','unit':'M €'}]


PRODUCTION_RESULT_LIST =  [{'name':u' Puissance installée','value':'','unit':'kW','key':"power"},
                     {'name':u'Débit','value':'','unit':'kg/s','key':"flow_rate"},
                     {'name':u'Température de départ','value':'','unit':u'°C','key':"t_supply"},
                     {'name':u'Température de retour','value':'','unit':u'°C','key':"t_return"},
                     ]


WIDTH_MAIN_RESULT_TABLE = 500
HEIGHT_MAIN_RESULT_TABLE = 172


WIDTH_OPTIM_RESULT_TABLE = 500
HEIGHT_OPTIM_RESULT_TABLE = 100 #+ 28.5

WIDTH_SETUP_UP_COST_TABLE = 500
HEIGHT_SETUP_UP_COST_TABLE = 200 #+ 28.5

WIDTH_WORKING_COST_TABLE = 500
HEIGHT_WORKING_COST_TABLE = 90 #+ 28.5

WIDTH_SECOND_RESULT_TABLE = 500
HEIGHT_SECOND_RESULT_TABLE = 263 #+ 28.5


WIDTH_PRODUCTION_RESULT_TABLE = 500
HEIGHT_PRODUCTION_RESULT_TABLE = 140 #+ 28.5
