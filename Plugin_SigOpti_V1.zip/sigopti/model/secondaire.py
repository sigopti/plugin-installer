# -*- coding: utf-8 -*-
#/***************************************************************************
#
# Sigopti
#                     -------------------
#     begin           : 2018-09-10
#     git sha             : $Format:%H$
#     copyright        : (C) 2018 by CREM Financed through Grant
#                           : Agreement 1705C0046 Agence de l'Environnement
#                           : et de la Maîtrise de l'Energie here after ADEME
#                           : Consortium: Nobatek, FNCCR and CREM
#     email           : info@crem.ch
# ***************************************************************************/

from qgis.core import *
from PyQt5.QtCore import *
from .processing_functions import *

from qgis import *



class Secondaire:

    def __init__(self, _buffer_distance_value,_consommation_minimum_value,consommation_shapefile,feeder_shapefile,_output_path):

        # inputs from user
        self._output_path =_output_path
        self._buffer_distance_value = _buffer_distance_value
        self._consommation_shapefile= consommation_shapefile
        self._feeder_shapefile = feeder_shapefile
        self._consommation_minimum_value= _consommation_minimum_value


    def generate(self):
        """
        This function generate the secondaire
        :param met_param: the type of meterological parameters
        :param station: the name of the meteorological station (string)
        :return:
        """

        processing = Processing_function()
        buffer = processing.native_buffer(self._feeder_shapefile,self._buffer_distance_value,self._output_path)
        intersection = processing.native_intersection(self._consommation_shapefile,buffer,self._output_path)
        pointsalonglines = processing.qgis_pointsalongline(self._feeder_shapefile,self._output_path)
        extractbyattribute = processing.native_extractbyattribute(intersection,self._consommation_minimum_value,self._output_path)
        distancetonearesthublinetohub = processing.qgis_distancetonearesthublinetohub(extractbyattribute,pointsalonglines,self._output_path)
        extendlines= processing.qgis_extendlines(distancetonearesthublinetohub,self._output_path)
        splitwithlines = processing.native_splitwithlines(self._feeder_shapefile, extendlines,self._output_path)
        feeder_seg = processing.native_explodelines(splitwithlines,self._output_path)
        multiparttosingleparts = processing.native_multiparttosingleparts(extractbyattribute,self._output_path)
        return buffer,multiparttosingleparts,feeder_seg,distancetonearesthublinetohub,extendlines

