# -*- coding: utf-8 -*-
#/***************************************************************************
#
# Sigopti
#                     -------------------
#     begin           : 2018-09-10
#     git sha             : $Format:%H$
#     copyright        : (C) 2018 by CREM Financed through Grant
#                           : Agreement 1705C0046 Agence de l'Environnement
#                           : et de la Maîtrise de l'Energie here after ADEME
#                           : Consortium: Nobatek, FNCCR and CREM
#     email           : info@crem.ch
# ***************************************************************************/

from PyQt5.QtCore import *
from PyQt5.QtGui import  *
from PyQt5.QtWidgets import QFileDialog, QTableWidgetItem,QAbstractItemView
import logging
from qgis.core import *
from qgis import *
from PyQt5 import QtWidgets
from qgis.gui import *

import requests
from PyQt5.QtCore import pyqtSignal
# Initialize Qt resources from file resources.py
# Import the code for the dialog
import sys

from PyQt5 import QtNetwork

class CheckConnectivity(QtCore.QObject):
    def __init__(self,iface, *args, **kwargs):
        QtCore.QObject.__init__(self, *args, **kwargs)
        url = QtCore.QUrl("https://www.google.com/")
        req = QtNetwork.QNetworkRequest(url)
        self.net_manager = QtNetwork.QNetworkAccessManager()
        self.res = self.net_manager.get(req)
        self.iface = iface
        self.res.finished.connect(self.processRes)
        self.res.error.connect(self.processErr)
        self.msg = QtWidgets.QMessageBox()

    @QtCore.pyqtSlot()
    def processRes(self):
        if self.res.bytesAvailable():
            message = "Vous êtes connecté à internet"
            self.iface.messageBar().pushMessage("Information", message, level = Qgis.Info, duration=2)
        self.res.deleteLater()

    @QtCore.pyqtSlot(QtNetwork.QNetworkReply.NetworkError)
    def processErr(self, code):
        message =  "Vous n'êtes pas connecté à internet. vous ne pouvez pas utilisé l'optimisation"
        self.iface.messageBar().pushMessage("Information", message, level = Qgis.Critical, duration=100)

