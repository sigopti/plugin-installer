# -*- coding: utf-8 -*-
#/***************************************************************************
#
# Sigopti
#                     -------------------
#     begin           : 2018-09-10
#     git sha             : $Format:%H$
#     copyright        : (C) 2018 by CREM Financed through Grant
#                           : Agreement 1705C0046 Agence de l'Environnement
#                           : et de la Maîtrise de l'Energie here after ADEME
#                           : Consortium: Nobatek, FNCCR and CREM
#     email           : info@crem.ch
# ***************************************************************************/
import uuid
import json

from .constant import  PRODUCTION_SOURCE_LIST,MAIN_RESULT_LIST,SECONDE_RESULT_LIST


from PyQt5 import QtCore

from networkx.readwrite import json_graph

import threading
from PyQt5.QtCore import *
def generate_geotif_name(directory):
    filename = generate_file(directory, '.tif')
    return filename
def generate_json_name(directory):
    filename = generate_file(directory, '.json')
    return filename
def generate_shapefile_name(directory):
    filename = generate_file(directory, '.shp')
    return filename
def generate_csv_name(directory):
    filename = generate_file(directory, '.csv')
    return filename
def generate_archive(directory):
    filename = generate_file(directory, '.zip')
    return filename
def generate_gml_name(directory):
    filename = generate_file(directory, '.gml')
    return filename

def generate_file(directory,extension):
    filename = directory+'/' + str(uuid.uuid4()) + extension
    return filename

def display_layer(iface,path,name,type):

    layer = QgsVectorLayer(path, name,type)

    if not layer.isValid():
        iface.messageBar().pushCritical("Failed to load:", name)
        return
    iface.addVectorLayer(path, name, type)

def retrieveJson(h_dir):
    """

    :param h_dir:
    :return:
    """
    data2 = json_graph.node_link_data(h_dir)
    payload = [data2]

    return payload


def write_to_file_with_path(path, content):

    path = path
    name_file = os.path.basename(path)
    f= open(path,"w+")

    f.write(content)
    f.close
    return name_file,path


def write_result_to_content(content, length,power_tot,consumption_tot):


    consumption_tot_mwh = consumption_tot/1000
    power_tot_mw = power_tot /1000
    length = length
    thermal_density = consumption_tot_mwh / length
    power_density = power_tot_mw/ length
    intermediate_result = {
        "intermediate_result" : {
            "consumption_tot_mwh":consumption_tot_mwh,
            "power_tot_mw":power_tot_mw,
            "length":length,
            "thermal_density":thermal_density,
            "power_density":power_density,
        }
    }
    #the following will update the json
    content[0][0].update(intermediate_result)

    return content
def write_result_to_optim_content(content, result):
    optim_result = {
        'optim_result' : result['solution']

    }
    #the following will update the json
    content[0][0].update(optim_result)

    return content


def retrieve_content_file(path):

    f = open(path, "r")
    contents = f.read()
    f.close

    contents = json.loads(contents)

    return contents


def parallelise(some_callable_function):
    threading.Thread(target=some_callable_function).start()

def from_dict_to_unique_array(results,key):
    response = []
    for value in results:
        ze_value = value[key]
        response.append(ze_value)
    return response
def refine_array(list, accept):
    for dict in list:

        file_path = dict['path']
        if file_path != accept:
            exists = os.path.isfile(file_path)

            if not exists:
                list.remove(dict)
    return list
        # Store configuration file values


def setup_main_table(table):
    table.resize(500, 150)
    table.setRowCount(6)
    table.setColumnCount(3)

    # set label
    table.setHorizontalHeaderLabels(("Paramètres;Valeur;Unité;").split(";"))

    header = table.horizontalHeader()
    header.setSectionResizeMode(0, QtWidgets.QHeaderView.Stretch)
    header.setSectionResizeMode(1, QtWidgets.QHeaderView.ResizeToContents)
    header.setSectionResizeMode(2, QtWidgets.QHeaderView.ResizeToContents)

    return setup_table_and_field(table)


def setup_table_and_field(table):

    # set data
    item =  QTableWidgetItem(u"Température de départ maximale")
    item.setFlags( QtCore.Qt.ItemIsSelectable |  QtCore.Qt.ItemIsEnabled )
    table.setItem(0,0,item) #Item (1,1)
    table.setItem(0,1, QTableWidgetItem("80")) # Item (1,2)
    item =  QTableWidgetItem(u"°C")
    item.setFlags( QtCore.Qt.ItemIsSelectable |  QtCore.Qt.ItemIsEnabled )
    table.setItem(0,2, item)


    item =  QTableWidgetItem(u"Température de retour minimale")
    item.setFlags( QtCore.Qt.ItemIsSelectable |  QtCore.Qt.ItemIsEnabled )
    table.setItem(1,0,item) #Item (1,1)
    table.setItem(1,1, QTableWidgetItem("50")) # Item (1,2)
    item =  QTableWidgetItem(u"°C")
    item.setFlags( QtCore.Qt.ItemIsSelectable |  QtCore.Qt.ItemIsEnabled )
    table.setItem(1,2, item)


    item =  QTableWidgetItem(u"Coût unitaire de la chaudière")
    item.setFlags( QtCore.Qt.ItemIsSelectable |  QtCore.Qt.ItemIsEnabled )
    table.setItem(2,0,item) #Item (1,1)
    table.setItem(2,1, QTableWidgetItem("xxxx")) # Item (1,2)
    item =  QTableWidgetItem(u"€/kW")
    item.setFlags( QtCore.Qt.ItemIsSelectable |  QtCore.Qt.ItemIsEnabled )
    table.setItem(2,2, item)


    item =  QTableWidgetItem(u"Coût unitaire de l'énergie finale")
    item.setFlags( QtCore.Qt.ItemIsSelectable |  QtCore.Qt.ItemIsEnabled )
    table.setItem(3,0,item) #Item (1,1)
    table.setItem(3,1, QTableWidgetItem("xxxx")) # Item (1,2)
    item =  QTableWidgetItem(u"€/kWh")
    item.setFlags( QtCore.Qt.ItemIsSelectable |  QtCore.Qt.ItemIsEnabled )
    table.setItem(3,2, item)

    item =  QTableWidgetItem(u"Rendement de la chaudière")
    item.setFlags( QtCore.Qt.ItemIsSelectable |  QtCore.Qt.ItemIsEnabled )
    table.setItem(4,0,item) #Item (1,1)
    table.setItem(4,1, QTableWidgetItem("xx")) # Item (1,2)
    item =  QTableWidgetItem(u"%")
    item.setFlags( QtCore.Qt.ItemIsSelectable |  QtCore.Qt.ItemIsEnabled )
    table.setItem(4,2, item)

    item =  QTableWidgetItem(u"Taux d'inflation de l'énergie utilisée")
    item.setFlags( QtCore.Qt.ItemIsSelectable |  QtCore.Qt.ItemIsEnabled )
    table.setItem(5,0,item) #Item (1,1)
    table.setItem(5,1, QTableWidgetItem("xx")) # Item (1,2)
    item =  QTableWidgetItem(u"%")
    item.setFlags( QtCore.Qt.ItemIsSelectable |  QtCore.Qt.ItemIsEnabled )
    table.setItem(5,2, item)
    table.setSelectionMode(QAbstractItemView.NoSelection)

    temp = table.itemAt(0,1)
    return table


def setup_table_and_from_dict(production_source,table):

    # set data

    if production_source is not None:
        for name, source_parameter in production_source.items():

            if name is "t_out_max":
                item = QTableWidgetItem()
                item.setText(source_parameter['value'])
                table.setItem(0, 1, item)
            elif name is "t_in_min":
                item = QTableWidgetItem()
                item.setText(source_parameter['value'])
                table.setItem(1, 1, item)
            elif name is "production_unitary_cost":
                item = QTableWidgetItem()
                item.setText(source_parameter['value'])
                table.setItem(2, 1, item)
            elif name is "energy_unitary_cost":
                item = QTableWidgetItem()
                item.setText(source_parameter['value'])
                table.setItem(3, 1, item)
            elif name is "efficiency":
                item = QTableWidgetItem()
                item.setText(source_parameter['value'])
                table.setItem(4, 1, item)
            elif name is "energy_cost_inflation_rate":
                item = QTableWidgetItem()
                item.setText(source_parameter['value'])
                table.setItem(5, 1, item)


def setup_table_and_from_dict_main_result(intermediate_result,table):

    # set data

        item = QTableWidgetItem()
        consumption_tot_mwh = intermediate_result['consumption_tot_mwh']
        #print('type consumption_tot_mwh',type(consumption_tot_mwh))
        #print('value consumption_tot_mwh',consumption_tot_mwh)


        item.setText(str(round(consumption_tot_mwh,3)))
        table.setItem(0, 1, item)

        item = QTableWidgetItem()
        item.setText(str(round(intermediate_result['power_tot_mw'], 3)))
        table.setItem(1, 1, item)

        item = QTableWidgetItem()
        item.setText(str(round(intermediate_result['length'], 3)))
        table.setItem(2, 1, item)

        item = QTableWidgetItem()
        item.setText(str(round(intermediate_result['thermal_density'], 3)))
        table.setItem(3, 1, item)

        item = QTableWidgetItem()
        item.setText(str(round(intermediate_result['power_density'], 3)))
        table.setItem(4, 1, item)

def setup_table_and_from_dict_optim_result(intermediate_result,table):
    optim_result = intermediate_result['global_indicators']
    # set data

   # item = QTableWidgetItem()
    #item.setText(str(intermediate_result['exchangers_installation_cost']))
    #table.setItem(0, 1, item)
    try:
        global_cost = float(optim_result['total_cost'])

        item = QTableWidgetItem()
        item.setText(str(round(global_cost,3)))
        table.setItem(0, 1, item)

        item = QTableWidgetItem()
        item.setText(str(round(optim_result['heat_production_cost'],3)))
        table.setItem(1, 1, item)


        item = QTableWidgetItem()
        item.setText(str(round(optim_result['production_intallation_cost'],3)))
        table.setItem(2, 1, item)

        item = QTableWidgetItem()
        item.setText(str(round(optim_result['exchangers_installation_cost'],3)))
        table.setItem(3, 1, item)

        item = QTableWidgetItem()
        item.setText(str(round(optim_result['network_cost'],3)))
        table.setItem(4, 1, item)

        item = QTableWidgetItem()
        item.setText(str(round(optim_result['trenches_cost'],3)))
        table.setItem(5, 1, item)

        item = QTableWidgetItem()
        item.setText(str(round(optim_result['pipes_cost'],3)))
        table.setItem(6, 1, item)

        item = QTableWidgetItem()
        item.setText(str(round(optim_result['pumps_operation_cost'],3)))
        table.setItem(7, 1, item)
    except:
        pass

def setup_table_and_from_dict_optim_result_for_k(optim_result,table):


    # set data

    # item = QTableWidgetItem()
    #item.setText(str(intermediate_result['exchangers_installation_cost']))
    #table.setItem(0, 1, item)
    try:
        power = float(optim_result['power'])

        item = QTableWidgetItem()
        item.setText(str(round(power,3)))
        table.setItem(0, 1, item)

        item = QTableWidgetItem()
        item.setText(str(round(optim_result['flow_rate'],3)))
        table.setItem(1, 1, item)


        item = QTableWidgetItem()
        item.setText(str(round(optim_result['t_supply'],3)))
        table.setItem(2, 1, item)

        item = QTableWidgetItem()
        item.setText(str(round(optim_result['t_return'],3)))
        table.setItem(3, 1, item)

    except:
        pass





    # table.itemAt(1,2).setText(source_parameter['value'])



from PyQt5.QtWidgets import QFileDialog, QTableWidgetItem,QAbstractItemView

from qgis.core import *
from qgis import *
from PyQt5 import QtWidgets
from qgis.gui import *

import requests

# Initialize Qt resources from file resources.py
# Import the code for the dialog
import sys


def layer_with_url_can_be_added(url,title,type,iface):

    layer = QgsRasterLayer(url, title, type)
    if not layer.isValid():
        iface.messageBar().pushMessage("Erreur", "impossible de charger cette layer", level=Qgis.Critical)
    else:
        return layer, layer.isValid()



def setup_secondary_table(table):
    table.resize(500, 150)
    table.setRowCount(6)
    table.setColumnCount(3)

    # set label
    table.setHorizontalHeaderLabels(("Paramètres;Valeur;Unité;").split(";"))

    header = table.horizontalHeader()
    header.setSectionResizeMode(0, QtWidgets.QHeaderView.Stretch)
    header.setSectionResizeMode(1, QtWidgets.QHeaderView.ResizeToContents)
    header.setSectionResizeMode(2, QtWidgets.QHeaderView.ResizeToContents)
    # set data
    item =  QTableWidgetItem(u"Température de départ maximale")
    item.setFlags( QtCore.Qt.ItemIsSelectable |  QtCore.Qt.ItemIsEnabled )
    table.setItem(0,0,item) #Item (1,1)
    table.setItem(0,1, QTableWidgetItem("80")) # Item (1,2)
    item =  QTableWidgetItem(u"°C")
    item.setFlags( QtCore.Qt.ItemIsSelectable |  QtCore.Qt.ItemIsEnabled )
    table.setItem(0,2, item)


    item =  QTableWidgetItem(u"Température de retour minimale")
    item.setFlags( QtCore.Qt.ItemIsSelectable |  QtCore.Qt.ItemIsEnabled )
    table.setItem(1,0,item) #Item (1,1)
    table.setItem(1,1, QTableWidgetItem("50")) # Item (1,2)
    item =  QTableWidgetItem(u"°C")
    item.setFlags( QtCore.Qt.ItemIsSelectable |  QtCore.Qt.ItemIsEnabled )
    table.setItem(1,2, item)


    item =  QTableWidgetItem(u"Coût unitaire de la chaudière")
    item.setFlags( QtCore.Qt.ItemIsSelectable |  QtCore.Qt.ItemIsEnabled )
    table.setItem(2,0,item) #Item (1,1)
    table.setItem(2,1, QTableWidgetItem("xxxx")) # Item (1,2)
    item =  QTableWidgetItem(u"€/kW")
    item.setFlags( QtCore.Qt.ItemIsSelectable |  QtCore.Qt.ItemIsEnabled )
    table.setItem(2,2, item)



    item =  QTableWidgetItem(u"Coût unitaire de l'énergie finale")
    item.setFlags( QtCore.Qt.ItemIsSelectable |  QtCore.Qt.ItemIsEnabled )
    table.setItem(3,0,item) #Item (1,1)
    table.setItem(3,1, QTableWidgetItem("xxxx")) # Item (1,2)
    item =  QTableWidgetItem(u"€/kWh")
    item.setFlags( QtCore.Qt.ItemIsSelectable |  QtCore.Qt.ItemIsEnabled )
    table.setItem(3,2, item)

    item =  QTableWidgetItem(u"Rendement de la chaudière")
    item.setFlags( QtCore.Qt.ItemIsSelectable |  QtCore.Qt.ItemIsEnabled )
    table.setItem(4,0,item) #Item (1,1)
    table.setItem(4,1, QTableWidgetItem("xx")) # Item (1,2)
    item =  QTableWidgetItem(u"%")
    item.setFlags( QtCore.Qt.ItemIsSelectable |  QtCore.Qt.ItemIsEnabled )
    table.setItem(4,2, item)

    item =  QTableWidgetItem(u"Taux d'inflation de l'énergie utilisée")
    item.setFlags( QtCore.Qt.ItemIsSelectable |  QtCore.Qt.ItemIsEnabled )
    table.setItem(5,0,item) #Item (1,1)
    table.setItem(5,1, QTableWidgetItem("xx")) # Item (1,2)
    item =  QTableWidgetItem(u"%")
    item.setFlags( QtCore.Qt.ItemIsSelectable |  QtCore.Qt.ItemIsEnabled )
    table.setItem(5,2, item)
    table.setSelectionMode(QAbstractItemView.NoSelection)

    temp = table.itemAt(0,1)
    return table



def setup_others_table(table):
    table.resize(500, 250)
    table.setRowCount(9)
    table.setColumnCount(3)

    # set label
    table.setHorizontalHeaderLabels(("Paramètres;Valeur;Unité;").split(";"))

    header = table.horizontalHeader()
    header.setSectionResizeMode(0, QtWidgets.QHeaderView.Stretch)
    header.setSectionResizeMode(1, QtWidgets.QHeaderView.ResizeToContents)
    header.setSectionResizeMode(2, QtWidgets.QHeaderView.ResizeToContents)
    # set data
    item =  QTableWidgetItem(u"Pertes thermiques")
    item.setFlags( QtCore.Qt.ItemIsSelectable |  QtCore.Qt.ItemIsEnabled )
    table.setItem(0,0,item) #Item (1,1)
    table.setItem(0,1, QTableWidgetItem("5")) # Item (1,2)
    item =  QTableWidgetItem(u"%")
    item.setFlags( QtCore.Qt.ItemIsSelectable |  QtCore.Qt.ItemIsEnabled )
    table.setItem(0,2, item)

    item =  QTableWidgetItem(u"Taux de foisonement")
    item.setFlags( QtCore.Qt.ItemIsSelectable |  QtCore.Qt.ItemIsEnabled )
    table.setItem(1,0,item) #Item (1,1)
    table.setItem(1,1, QTableWidgetItem("70")) # Item (1,2)
    item =  QTableWidgetItem(u"%")
    item.setFlags( QtCore.Qt.ItemIsSelectable |  QtCore.Qt.ItemIsEnabled )
    table.setItem(1,2, item)

    item =  QTableWidgetItem(u"Coût unitaire de tranchée aller-retour")
    item.setFlags( QtCore.Qt.ItemIsSelectable |  QtCore.Qt.ItemIsEnabled )
    table.setItem(2,0,item) #Item (1,1)
    table.setItem(2,1, QTableWidgetItem("800")) # Item (1,2)
    item =  QTableWidgetItem(u"€/m")
    item.setFlags( QtCore.Qt.ItemIsSelectable |  QtCore.Qt.ItemIsEnabled )
    table.setItem(2,2, item)

    item =  QTableWidgetItem(u"Diamètre intérieur maximum des canalisations")
    item.setFlags( QtCore.Qt.ItemIsSelectable |  QtCore.Qt.ItemIsEnabled )
    table.setItem(3,0,item) #Item (1,1)
    table.setItem(3,1, QTableWidgetItem("0.25")) # Item (1,2)
    item =  QTableWidgetItem(u"m")
    item.setFlags( QtCore.Qt.ItemIsSelectable |  QtCore.Qt.ItemIsEnabled )
    table.setItem(3,2, item)

    item =  QTableWidgetItem(u"Vitesse maximum dans les canalisations")
    item.setFlags( QtCore.Qt.ItemIsSelectable |  QtCore.Qt.ItemIsEnabled )
    table.setItem(4,0,item)
    table.setItem(4,1, QTableWidgetItem("3"))
    item =  QTableWidgetItem(u"m/s")
    item.setFlags( QtCore.Qt.ItemIsSelectable |  QtCore.Qt.ItemIsEnabled )
    table.setItem(4,2, item)

    item =  QTableWidgetItem(u"Taux d'actualisation pour le calcul de l'annuité des investissements initiaux")
    item.setFlags( QtCore.Qt.ItemIsSelectable |  QtCore.Qt.ItemIsEnabled )
    table.setItem(5,0,item) #Item (1,1)
    table.setItem(5,1, QTableWidgetItem("4")) # Item (1,2)
    item =  QTableWidgetItem(u"%")
    item.setFlags( QtCore.Qt.ItemIsSelectable |  QtCore.Qt.ItemIsEnabled )
    table.setItem(5,2, item)

    item =  QTableWidgetItem(u"Durée de fonctionement annuelle du RCU")
    item.setFlags( QtCore.Qt.ItemIsSelectable |  QtCore.Qt.ItemIsEnabled )
    table.setItem(6,0,item) #Item (1,1)
    table.setItem(6,1, QTableWidgetItem("5808")) # Item (1,2)
    item =  QTableWidgetItem(u"h/an")
    item.setFlags( QtCore.Qt.ItemIsSelectable |  QtCore.Qt.ItemIsEnabled )
    table.setItem(6,2, item)

    item =  QTableWidgetItem(u"Durée d'amortissement (Calcul coût global)")
    item.setFlags( QtCore.Qt.ItemIsSelectable |  QtCore.Qt.ItemIsEnabled )
    table.setItem(7,0,item) #Item (1,1)
    table.setItem(7,1, QTableWidgetItem("30")) # Item (1,2)
    item =  QTableWidgetItem(u"ans")
    item.setFlags( QtCore.Qt.ItemIsSelectable |  QtCore.Qt.ItemIsEnabled )
    table.setItem(7,2, item)

    item =  QTableWidgetItem(u"Ratio du coût de pompage/coût global")
    item.setFlags( QtCore.Qt.ItemIsSelectable |  QtCore.Qt.ItemIsEnabled )
    table.setItem(8,0,item) #Item (1,1)
    table.setItem(8,1, QTableWidgetItem("1")) # Item (1,2)
    item =  QTableWidgetItem(u"%")
    item.setFlags( QtCore.Qt.ItemIsSelectable |  QtCore.Qt.ItemIsEnabled )
    table.setItem(8,2, item)
    table.setSelectionMode(QAbstractItemView.NoSelection)

    return table
def get_value_from_selected_name( index, array):
    """

    :param name:
    :return:
    """
    code = from_dict_to_unique_array(array,'code')[index]
    return code


def get_production_source_from_code(code):
    if code is not None:
        dict = PRODUCTION_SOURCE_LIST[code]
        return dict
    else:
        return None


def init_setup_main_results_table(table,array,width, height):
    table.resize(width, height)
    table.setRowCount(len(array))
    table.setColumnCount(3)

    # set label
    table.setHorizontalHeaderLabels(("Sortie;Valeur;Unité;").split(";"))

    header = table.horizontalHeader()
    header.setSectionResizeMode(0, QtWidgets.QHeaderView.Stretch)
    header.setSectionResizeMode(1, QtWidgets.QHeaderView.ResizeToContents)
    header.setSectionResizeMode(2, QtWidgets.QHeaderView.ResizeToContents)

    return table

def setup_results_table(table,array,width, height):
    table = init_setup_main_results_table(table,array,width, height)
    cpt = 0
    for result in array:
        item =  QTableWidgetItem(result['name'])
        item.setFlags( QtCore.Qt.ItemIsSelectable | QtCore.Qt.ItemIsEnabled )
        table.setItem(cpt,0,item)
        item =  QTableWidgetItem(result['value'])
        item.setFlags( QtCore.Qt.ItemIsSelectable | QtCore.Qt.ItemIsEnabled )
        table.setItem(cpt,1, item)
        item =  QTableWidgetItem(result['unit'])
        item.setFlags( QtCore.Qt.ItemIsSelectable | QtCore.Qt.ItemIsEnabled )
        table.setItem(cpt,2, item)
        cpt = cpt + 1
    table.setSelectionMode(QAbstractItemView.NoSelection)
    return table

def setup_main_results_table(table):
    table.resize(500, 172)
    table.setRowCount(5)
    table.setColumnCount(3)

    # set label
    table.setHorizontalHeaderLabels(("Paramètres;Valeur;Unité;").split(";"))

    header = table.horizontalHeader()
    header.setSectionResizeMode(0, QtWidgets.QHeaderView.Stretch)
    header.setSectionResizeMode(1, QtWidgets.QHeaderView.ResizeToContents)
    header.setSectionResizeMode(2, QtWidgets.QHeaderView.ResizeToContents)

    return setup_table_and_results_field(table)

def setup_table_and_results_field(table):

    # set data
    item =  QTableWidgetItem(u"Consommation totale raccordée")
    item.setFlags( QtCore.Qt.ItemIsSelectable |  QtCore.Qt.ItemIsEnabled )
    table.setItem(0,0,item) #Item (1,1)
    item =  QTableWidgetItem(u"")
    item.setFlags( QtCore.Qt.ItemIsSelectable |  QtCore.Qt.ItemIsEnabled )
    table.setItem(0,1, item) # Item (1,2)
    item =  QTableWidgetItem(u"kWh")
    item.setFlags( QtCore.Qt.ItemIsSelectable |  QtCore.Qt.ItemIsEnabled )
    table.setItem(0,2, item)

    item =  QTableWidgetItem(u"Puissance totale raccordée")
    item.setFlags( QtCore.Qt.ItemIsSelectable |  QtCore.Qt.ItemIsEnabled )
    table.setItem(1,0,item) #Item (1,1)
    item =  QTableWidgetItem(u"")
    item.setFlags( QtCore.Qt.ItemIsSelectable |  QtCore.Qt.ItemIsEnabled )
    table.setItem(1,1, item) # Item (1,2)
    item =  QTableWidgetItem(u"kW")
    item.setFlags( QtCore.Qt.ItemIsSelectable |  QtCore.Qt.ItemIsEnabled )
    table.setItem(1,2, item)

    item =  QTableWidgetItem(u"Longueur totale de réseau (aller-simple)")
    item.setFlags( QtCore.Qt.ItemIsSelectable |  QtCore.Qt.ItemIsEnabled )
    table.setItem(2,0,item) #Item (1,1)
    item =  QTableWidgetItem(u"")
    item.setFlags( QtCore.Qt.ItemIsSelectable |  QtCore.Qt.ItemIsEnabled )
    table.setItem(2,1, item) # Item (1,2)
    item =  QTableWidgetItem(u"m")
    item.setFlags( QtCore.Qt.ItemIsSelectable |  QtCore.Qt.ItemIsEnabled )
    table.setItem(2,2, item)

    item =  QTableWidgetItem(u"Densité thermique")
    item.setFlags( QtCore.Qt.ItemIsSelectable |  QtCore.Qt.ItemIsEnabled )
    table.setItem(3,0,item) #Item (1,1)
    item =  QTableWidgetItem(u"")
    item.setFlags( QtCore.Qt.ItemIsSelectable |  QtCore.Qt.ItemIsEnabled )
    table.setItem(3,1, item) # Item (1,2)
    item =  QTableWidgetItem(u"MWh/ml")
    item.setFlags( QtCore.Qt.ItemIsSelectable |  QtCore.Qt.ItemIsEnabled )
    table.setItem(3,2, item)

    item =  QTableWidgetItem(u"Densité de puissance")
    item.setFlags( QtCore.Qt.ItemIsSelectable |  QtCore.Qt.ItemIsEnabled )
    table.setItem(4,0,item) #Item (1,1)
    item =  QTableWidgetItem(u"")
    item.setFlags( QtCore.Qt.ItemIsSelectable |  QtCore.Qt.ItemIsEnabled )
    table.setItem(4,1, item) # Item (1,2)
    item =  QTableWidgetItem(u"MW/ml")
    item.setFlags( QtCore.Qt.ItemIsSelectable |  QtCore.Qt.ItemIsEnabled )
    table.setItem(4,2, item)

    table.setSelectionMode(QAbstractItemView.NoSelection)

    return table
def from_table_view_to_payload(table_main,table_seconde,table_others,coverage_rate):

    technologies =  {
        "k1": {
            "efficiency":  float(table_main.item(4,1).text())/100, #rendement de technologie
            "t_out_max": float(table_main.item(0,1).text()), #Température de départ maximale
            "t_in_min": float(table_main.item(1,1).text()), #Température de retour minimal
            "production_unitary_cost": float(table_main.item(2,1).text()), # Coût unitaire de la chaudière
            "energy_unitary_cost": float(table_main.item(3,1).text()),#Coût unitaire de l'énergie finale
            "energy_cost_inflation_rate":float(table_main.item(5,1).text())/100,#nflation de l'énergie liée à la technologie
            "coverage_rate":float(coverage_rate)/100


        },
        "k2": {
            "efficiency":  float(table_seconde.item(4,1).text())/100,
            "t_out_max":float( table_seconde.item(0,1).text()),
            "t_in_min": float(table_seconde.item(1,1).text()),
            "production_unitary_cost":float( table_seconde.item(2,1).text()),
            "energy_unitary_cost": float(table_seconde.item(3,1).text()),
            "energy_cost_inflation_rate":float(table_seconde.item(5,1).text())/100,
            #"coverage_rate":float(coverage_rate)/100
        },


    }



    parameters =  {
        "heat_loss_rate": float(table_others.item(0,1).text())/100, # taux de pertes thermiques
        "simultaneity_ratio": float(table_others.item(1,1).text())/100, # taux de pertes thermiques
        # "speed_min": float(table_others.item(5,1).text()),# borne vitesse min, 0.1m/s d'après Techniques de l'Ingénieur
        "speed_max": float(table_others.item(4,1).text()),# borne vitesse max, 3m/s d'après Techniques de l'Ingénieur
        #"diameter_int_min": float(table_others.item(4,1).text()),# diamètre interieur min du tuyau (m)
        "diameter_int_max": float(table_others.item(3,1).text()),# diamètre interieur max du tuyau (m)
        "operation_time": float(table_others.item(6,1).text()),  # durée de fonctionnement annuelle du RCU
        "depreciation_period": float(table_others.item(7,1).text()),# duree d'amortissement
        "discout_rate": float(table_others.item(5,1).text())/100,# taux d'actualisation pour le calcul de l'annuite des investissements initiaux
        "trench_unit_cost": float(table_others.item(2,1).text()),# coût unitaire de tranchee aller-retour
        "pump_energy_ratio_cost": float(table_others.item(8,1).text())/100    # ratio du coût de pompage/coût global



    }

    return technologies,parameters
