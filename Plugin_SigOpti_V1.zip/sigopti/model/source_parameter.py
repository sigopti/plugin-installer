# -*- coding: utf-8 -*-
#/***************************************************************************
#
# Sigopti
#                     -------------------
#     begin           : 2018-09-10
#     git sha             : $Format:%H$
#     copyright        : (C) 2018 by CREM Financed through Grant
#                           : Agreement 1705C0046 Agence de l'Environnement
#                           : et de la Maîtrise de l'Energie here after ADEME
#                           : Consortium: Nobatek, FNCCR and CREM
#     email           : info@crem.ch
# ***************************************************************************/
from qgis.core import *
from PyQt5.QtCore import *


from qgis import *


class SourceParameter:

    def __init__(self,name, value, unit):

        # inputs from user
        self._name = name
        self._value = value
        self._unit = unit



    def get_name(self):
        """

        :return:
        """
        return self._name

    def set_name(self, name):
        """
        :param value:
        :return:
        """
        self._name = name

    def get_value(self):
        """

        :return:
        """
        return self._value

    def set_value(self, value):
        """
        :param value:
        :return:
        """
        self._value = value


    def get_unit(self):
        """

        :return:
        """
        return self._name

    def set_unit(self, unit):
        """
        :param value:
        :return:
        """
        self._unit = unit
