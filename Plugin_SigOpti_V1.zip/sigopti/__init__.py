# -*- coding: utf-8 -*-
#/***************************************************************************
#
# Sigopti
#                     -------------------
#     begin           : 2018-09-10
#     git sha             : $Format:%H$
#     copyright        : (C) 2018 by CREM Financed through Grant
#                           : Agreement 1705C0046 Agence de l'Environnement
#                           : et de la Maîtrise de l'Energie here after ADEME
#                           : Consortium: Nobatek, FNCCR and CREM
#     email           : info@crem.ch
# ***************************************************************************/


# noinspection PyPep8Naming



def classFactory(iface):  # pylint: disable=invalid-name
    """Load Sigopti class from file Sigopti.

    :param iface: A QGIS interface instance.
    :type iface: QgsInterface
    """
    #
    from .sigopti import Sigopti
    return Sigopti(iface)
