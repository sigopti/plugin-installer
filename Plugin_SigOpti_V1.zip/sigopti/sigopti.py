# -*- coding: utf-8 -*-
#/***************************************************************************
#
# Sigopti
#                     -------------------
#     begin           : 2018-09-10
#     git sha             : $Format:%H$
#     copyright        : (C) 2018 by CREM Financed through Grant
#                           : Agreement 1705C0046 Agence de l'Environnement
#                           : et de la Maîtrise de l'Energie here after ADEME
#                           : Consortium: Nobatek, FNCCR and CREM
#     email           : info@crem.ch
# ***************************************************************************/
from .model import *
import requests
from .sigopti_dialog import *
from .sigopti_display_results import *
from .sigopti_run_optimisation import *
from PyQt5.QtCore import *
from PyQt5.QtGui import *
from PyQt5.QtWidgets import *
from PyQt5.QtNetwork import QNetworkSession
import os.path
class QThread1(QtCore.QThread):

    sig1 = pyqtSignal(str, int, int)

    def __init__(self, task_id, parent=None):
        QtCore.QThread.__init__(self, parent)
        self.task_id = task_id

    def connect(self, lineftxt):
        self.source_txt = lineftxt

    def run(self):
        while requests.get(
                HOST + '/solver/tasks/{}/status'.format(self.task_id)).json()['status'] in ('waiting', 'ongoing'):
            time.sleep(1)

class Sigopti:
    """QGIS Plugin Implementation."""
    def __init__(self, iface):
        """Constructor.

        :param iface: An interface instance that will be passed to this class
            which provides the hook by which you can manipulate the QGIS
            application at run time.
        :type iface: QgsInterface
        """
        # Save reference to the QGIS interface
        saver = Saver()
        #saver.save_value_with_key('network_configuration_list',[{"name":"Configuration de réseau à optimiser","path":"no_path"} ])
        self.iface = iface
        self.osm_map = None
        self.graph = None
        self.output_path = None
        self.table_main = None
        self.feeder = None
        self.sources = None
        self.progress_bar = QProgressBar()
        self.ui_communication = UiCommunication()
        self.consommation = None
        self.m_netReply = None
        self.m_netAccessManager = QNetworkAccessManager()
        self.root_layers = QgsProject.instance().layerTreeRoot()
        self.optimisation = Optimisation()
        self.sig = pyqtSignal(str)
        # initialize plugin directory
        self.plugin_dir = os.path.dirname(__file__)
        # initialize locale
        locale = QSettings().value('locale/userLocale')[0:2]
        locale_path = os.path.join(
            self.plugin_dir,
            'i18n',
            'Sigopti_{}.qm'.format(locale))
        if os.path.exists(locale_path):
           self.translator = QTranslator()
           self.translator.load(locale_path)
           if qVersion() > '4.3.3':
               QCoreApplication.installTranslator(self.translator)

        # Create the dialog (after translation) and keep reference
        self.dlg = SigoptiDialog()
        self.dlg_results = SigoptiDisplayResults()
        self.dlg_run_optimisation = SigoptiRunOptimistation()
        self.bar = QgsMessageBar()
        self.bar.setSizePolicy(QSizePolicy.Minimum, QSizePolicy.Fixed)
        self.dlg_run_optimisation.hl_messagebar.addWidget(self.bar)
        self.optimisation_spinner = QtWaitingSpinner(self.dlg_run_optimisation,True,  False, Qt.ApplicationModal)
        # Declare instance attributes
        self.actions = []
        self.menu =  None #self.tr(u'&Sigopti')
        # TODO: We are going to let the user set this up in a future iteration
        self.toolbar = self.iface.addToolBar(u'Sigopti')
        self.toolbar.setObjectName(u'Sigopti')
        self.m_netAccessManager = QNetworkAccessManager()
        self.m_netSession = QNetworkSession(self.m_netAccessManager.configuration())
        self.cancel_request_optimisation = False
    def add_submenu(self, submenu):
        if self.menu != None:
            self.menu.addMenu(submenu)
        else:
            self.iface.addPluginToMenu("&Sigopti", submenu.menuAction())
    # noinspection PyMethodMayBeStatic
    def tr(self, message):
        """Get the translation for a string using Qt translation API.

        We implement this ourselves since we do not inherit QObject.

        :param message: String for translation.
        :type message: str, QString

        :returns: Translated version of message.
        :rtype: QString
        """
        return QCoreApplication.translate('Sigopti', message)

    def add_layer(self,layer,root_layers):
        QgsProject.instance().addMapLayer(layer, False)
        root_layers.insertLayer(999, layer)

    def add_osm_map(self):
        layer, valid = layer_with_url_can_be_added("type=xyz&zmin=0&zmax=19&url=http://c.tile.openstreetmap.org/{z}/{x}/{y}.png", "OSM", "wms",self.iface)
        if valid is True:
           self.add_layer(layer,self.root_layers)

    def add_satellite_view(self):
        layer, valid = layer_with_url_can_be_added("type=xyz&zmin=0&zmax=19&url=http://c.tile.openstreetmap.org/{z}/{x}/{y}.png", "OSM", "wms",self.iface)
        if valid is True:
            self.add_layer(layer,self.root_layers)

    def initGui(self):

        saver = Saver()
       # saver.delete_all_values()


        """Create the menu entries and toolbar icons inside the QGIS GUI."""
        icon = QIcon(os.path.dirname(__file__) + "/icons/sigopti.png")
        self.menu = QtWidgets.QMenu(QCoreApplication.translate("Sigopti", "SigOpti"))

        self.iface.mainWindow().menuBar().insertMenu(self.iface.firstRightStandardMenu().menuAction(), self.menu)
        self.addMapMenu()
        # Import/ Export Submenu
        self.donnees_menu = QtWidgets.QMenu(QCoreApplication.translate("Sigopti", "&Données d'entrée"))
        icon = QIcon(os.path.dirname(__file__) + "/icons/load_icon_v2.png")

        self.iface.mainWindow().setWindowIcon(icon)
        self.consommation_menu = QtWidgets.QMenu( QCoreApplication.translate("Sigopti", "&Consommations"))
        self.donnees_menu.setIcon(icon)
        self.donnees_menu.addMenu(self.consommation_menu)
        # sous menu feeder load_icon_v2.png
        self.feeder_menu = QtWidgets.QMenu(QCoreApplication.translate("Sigopti", "&Feeder"))
        self.donnees_menu.addMenu(self.feeder_menu)
        self.sources_menu = QtWidgets.QMenu(QCoreApplication.translate("Sigopti", "&Sources"))
        self.donnees_menu.addMenu(self.sources_menu)
        self.add_submenu(self.donnees_menu)
        # menu feeder
        icon = QIcon(os.path.dirname(__file__) + "/icons/mmqgis_attribute_join.png")
        feeder_saved = saver.get_value_with_key('feeder',"")
        self.import_shapefile_feeder = QtWidgets.QAction(icon, "Importer un Feeder (shapefile lignes)", self.iface.mainWindow())
        self.import_shapefile_feeder.triggered.connect(self.select_input_shp_feeder)
        self.feeder_menu.addAction(self.import_shapefile_feeder)
        # menu Consommation
        icon = QIcon(os.path.dirname(__file__) + "/icons/mmqgis_attribute_join.png")
        consommations_saved = saver.get_value_with_key('consommation',"")
        self.import_shapefile_comsommation= QtWidgets.QAction(icon, "Importer des consommations (shapefile points)" , self.iface.mainWindow())
        self.import_shapefile_comsommation.triggered.connect(self.select_input_shp_consomation)
        self.consommation_menu.addAction(self.import_shapefile_comsommation)
        # menu Sources
        icon = QIcon(os.path.dirname(__file__) + "/icons/mmqgis_attribute_join.png")
        sources_saved = saver.get_value_with_key('sources_unique',"")
        #print("sources_saved",sources_saved)
        self.ajouter_sources= QtWidgets.QAction(icon, "Importer une source (shapefile point) ", self.iface.mainWindow())
        self.ajouter_sources.triggered.connect(self.select_input_shp_sources)
        self.sources_menu.addAction(self.ajouter_sources)
        # reseaux menu
        icon = QIcon(os.path.dirname(__file__) + "/icons/reseaux.png")
        self.reseaux_menu = QtWidgets.QMenu(QCoreApplication.translate("Sigopti", "&Réseaux"))
        self.reseaux_menu.setIcon(icon)
        self.add_submenu(self.reseaux_menu)

        # Générer le réseaux complet action
        icon = QIcon(os.path.dirname(__file__) + "/icons/mmqgis_attribute_join.png")
        self.generer_reseau_action= QtWidgets.QAction(icon, "Générer et enregistrer une configuration de réseau complet", self.iface.mainWindow())
        self.generer_reseau_action.triggered.connect(self.generate_reseau)
        self.reseaux_menu.addAction(self.generer_reseau_action)
        icon = QIcon(os.path.dirname(__file__) + "/icons/optimisation.png")
        self.optimisation_menu = QtWidgets.QMenu(QCoreApplication.translate("Sigopti", "&Optimisation"))
        self.optimisation_menu.setIcon(icon)
        self.add_submenu(self.optimisation_menu)

        icon = QIcon(os.path.dirname(__file__) + "/icons/mmqgis_attribute_join.png")
        self.lancer_optimisation_action= QtWidgets.QAction(icon, "Lancer une optimisation", self.iface.mainWindow())
        self.lancer_optimisation_action.triggered.connect(self.lancer_optimisation_fenetre)
        self.optimisation_menu.addAction(self.lancer_optimisation_action)
        icon = QIcon(os.path.dirname(__file__) + "/icons/resultats.png")
        self.resultats_menu = QtWidgets.QMenu(QCoreApplication.translate("Sigopti", "&Résultats"))
        self.resultats_menu.setIcon(icon)
        self.add_submenu(self.resultats_menu)

        # Lancer une optimisation (et afficher les résultats
        icon = QIcon(os.path.dirname(__file__) + "/icons/mmqgis_attribute_join.png")
        self.network_analysis_action= QtWidgets.QAction(icon, "Analyse de réseau", self.iface.mainWindow())
        self.network_analysis_action.triggered.connect(self.run_result_windows)
        self.resultats_menu.addAction(self.network_analysis_action)
        self.enable_cancel_optim(False)


    def addMapMenu(self):
        # Add map Submenu
        self.add_map_menu = QtWidgets.QMenu(QCoreApplication.translate("Sigopti", "&Fond de carte"))
        icon = QIcon(os.path.dirname(__file__) + "/icons/fond_de_carte.png")

        self.add_map_menu.setIcon(icon)
        self.add_submenu(self.add_map_menu)

        icon = QIcon(os.path.dirname(__file__) + "/icons/osm.svg")
        self.display_osm= QtWidgets.QAction(icon, "Ajouter OpenStreetMap", self.iface.mainWindow())
        self.display_osm.triggered.connect(self.add_osm_map)
        self.add_map_menu.addAction(self.display_osm)

    def load_shapefiles_feeder(self, shp_path):
        """
        :param shp_path: physical path to the shapefile
        :return:
        """
        self.feeder = load_shapefiles( shp_path ,"feeder",self.iface,self.import_shapefile_feeder,"Importer un Feeder (shapefile lignes)")
        self.ui_communication.display_success_message(self.iface.messageBar(),"feeder", shp_path)

    def load_shapefiles_comsomation(self, shp_path):
        """
        :param shp_path: physical path to the
        """
        self.consommation = Layer(shp_path, "consommation", 'ogr')
        if not self.consommation.check_attribute_kwh():
            self.iface.messageBar().pushMessage("Erreur", "vous devez importer une consommation avec l'attribut kWh", level=Qgis.Critical)
            self.select_input_shp_consomation()

        self.consommation = load_shapefiles( shp_path ,"consommations",self.iface,self.import_shapefile_comsommation,"Importer des consommations (shapefile points)")
        self.ui_communication.display_success_message(self.iface.messageBar(),"consommation", shp_path)

    def load_shapefiles_souces(self, shp_path):
        """
        :param shp_path: physical path to the shapefile
        :return:
        """
        self.sources = load_shapefiles( shp_path ,"source_unique",self.iface,self.ajouter_sources,"Importer une source (shapefile point) ")
        self.ui_communication.display_success_message(self.iface.messageBar(),"sources", shp_path)


    def select_input_shp_consomation(self):
        try:
            filename , work_well = select_input_shp(self.dlg,"Importer des consommations (shapefile points)",'consommation')
            if work_well is True:
                self.ui_communication.display_success_message(self.iface.messageBar(),"consommation", filename)
                self.load_shapefiles_comsomation(filename)
        except:
            pass

    def select_input_shp_feeder(self):
        try:
            filename, work_well = select_input_shp(self.dlg,"Importer un Feeder (shapefile lignes)",'feeder')
            if work_well :
                self.load_shapefiles_feeder(filename)
        except:
            pass

    def select_input_shp_sources(self):
        try:
            filename , work_well = select_input_shp(self.dlg,"Importer une source (shapefile point)",'source ')
            if work_well is True:
                self.ui_communication.display_success_message(self.iface.messageBar(),"source", filename)
                self.load_shapefiles_souces(filename)
        except:
            pass

    def select_output_path(self,base_path=None, message='Selectionner le répertoire de sortie:'):
        saver = Saver()
        dir = QFileDialog.getExistingDirectory(None, message, saver.get_value_with_key('output_path',None), QFileDialog.ShowDirsOnly)
        if dir is not None and  dir:
            saver.save_value_with_key('output_path',dir)

        return dir

    def select_output_path_json(self):
        saver = Saver()
        dir = QFileDialog.getSaveFileName(None, 'Selectionner le répertoire de sortie de votre fichier de configuration', saver.get_value_with_key('output_path',None), "json (*.json);")

        return dir


    def unload(self):
                """Removes the plugin menu item and icon from QGIS GUI."""
                for action in self.actions:
                    self.iface.removePluginMenu(
                        self.tr(u'&Sigopti'),
                        action)
                    self.iface.removeToolBarIcon(action)
                # remove the toolbar
                del self.toolbar

    def run_result_windows(self):
        self.dlg_results.comboBox_config_files.clear()
        new_list = list(self.optimisation.get_configuration_list_name())
        new_list[0] = ' Configuration de réseau à analyser'
        self.dlg_results.comboBox_config_files.addItems(new_list)

        table_main = self.dlg_results.tableWidgetMainResults

        helper.setup_results_table(table_main,MAIN_RESULT_LIST,WIDTH_MAIN_RESULT_TABLE, HEIGHT_MAIN_RESULT_TABLE)

        table_result_optim = self.dlg_results.tableWidgetResultOptim
        helper.setup_results_table(table_result_optim,OPTIM_RESULT_LIST,WIDTH_OPTIM_RESULT_TABLE, HEIGHT_OPTIM_RESULT_TABLE)

        table_working_cost = self.dlg_results.tableWidgetWorking
        helper.setup_results_table(table_working_cost,WORKING_COST_RESULT_LIST,WIDTH_WORKING_COST_TABLE, HEIGHT_WORKING_COST_TABLE)

        table_second = self.dlg_results.tableWidgetSecondaryResults
        helper.setup_results_table(table_second,SETUP_UP_COST_RESULT_LIST,WIDTH_SETUP_UP_COST_TABLE, HEIGHT_SECOND_RESULT_TABLE)

        table_k1 = self.dlg_results.tableWidget_K1
        helper.setup_results_table(table_k1,PRODUCTION_RESULT_LIST,WIDTH_PRODUCTION_RESULT_TABLE, HEIGHT_PRODUCTION_RESULT_TABLE)

        table_k2 = self.dlg_results.tableWidget_K2
        helper.setup_results_table(table_k2,PRODUCTION_RESULT_LIST,WIDTH_PRODUCTION_RESULT_TABLE, HEIGHT_PRODUCTION_RESULT_TABLE)

        self.dlg_results.comboBox_config_files.currentIndexChanged.connect(
            lambda currentindex : [
                self.update_primary_result(currentindex,table_main,table_result_optim, table_working_cost, table_second,table_k1,table_k2)

            ] )
        #self.dlg_results.show()
        result = self.dlg_results.exec_()
        #setting up the configuration lambda in order to retrive the selected item

        #
        return result

    def update_primary_result(self,currentindex,table_main,table_result_optim, table_working_cost, table_second,table_k1,table_k2):

        table_main.clearContents()
        helper.setup_results_table(table_main,MAIN_RESULT_LIST,WIDTH_MAIN_RESULT_TABLE, HEIGHT_MAIN_RESULT_TABLE)

        table_second.clearContents()
        helper.setup_results_table(table_second,SETUP_UP_COST_RESULT_LIST,WIDTH_SETUP_UP_COST_TABLE, HEIGHT_SETUP_UP_COST_TABLE)

        table_result_optim.clearContents()
        helper.setup_results_table(table_result_optim,OPTIM_RESULT_LIST,WIDTH_OPTIM_RESULT_TABLE, HEIGHT_OPTIM_RESULT_TABLE)

        table_working_cost.clearContents()
        helper.setup_results_table(table_working_cost,WORKING_COST_RESULT_LIST,WIDTH_WORKING_COST_TABLE, HEIGHT_WORKING_COST_TABLE)

        table_k1.clearContents()
        helper.setup_results_table(table_k1,PRODUCTION_RESULT_LIST,WIDTH_PRODUCTION_RESULT_TABLE, HEIGHT_PRODUCTION_RESULT_TABLE)

        table_k2.clearContents()
        helper.setup_results_table(table_k2,PRODUCTION_RESULT_LIST,WIDTH_PRODUCTION_RESULT_TABLE, HEIGHT_PRODUCTION_RESULT_TABLE)

        self.optimisation.set_optimistation_path(currentindex)
        try:
            intermediate_result = self.optimisation.retrieve_content_file_to_dict(self.ui_communication,self.iface)
            setup_table_and_from_dict_main_result(intermediate_result,table_main)

            optim_result = self.optimisation.retrieve_content_file_to_dict_optim(self.ui_communication,self.iface)
            setup_table_optim_result(optim_result, table_result_optim,intermediate_result)
            setup_table_and_from_dict_optim_result(optim_result, table_second)
            setup_table_and_from_dict_working_result(optim_result, table_working_cost)


            k1 = optim_result['nodes']['production'][0]['technologies']['k1']
            setup_table_and_from_dict_optim_result_for_k(k1,table_k1)
            k2 = optim_result['nodes']['production'][0]['technologies']['k2']
            setup_table_and_from_dict_optim_result_for_k(k2,table_k2)
        except:
            pass


    def enable_cancel_optim(self, value):
        self.dlg_run_optimisation.cancelOptimButton.setEnabled(value)
        self.dlg_run_optimisation.cancelOptimButton.setVisible(value)
    def open_new_configuration(self):

       # print("optimisation_from_path",self.optimisation.get_configuration_from_path())
        path = select_output_configuration(self.dlg)
        self.dlg_results.comboBox_config_files.setCurrentIndex(7)
        #print("path ",path)

    def lancer_optimisation_fenetre(self):
        self.ui_communication.remove_former_message(self.bar)
        CheckConnectivity(self.iface)
        source_main_heats = self.optimisation.get_source_main_heats()
        source_appoint_heats = self.optimisation.get_source_appoint_heats()
        table_main = self.dlg_run_optimisation.tableWidgetMainParameter
        table_secondary = self.dlg_run_optimisation.tableWidgetSecondaryParameter
        table_others = self.dlg_run_optimisation.tableWidgetOthersParameter
        table_main = helper.setup_main_table(table_main)
        table_secondary = helper.setup_secondary_table(table_secondary)
        table_others = helper.setup_others_table(table_others)
        self.dlg_run_optimisation.comboBox_config_files.clear()

        new_list = list(self.optimisation.get_configuration_list_name())
        new_list[0] = 'Configuration de réseau à optimiser'
        self.dlg_run_optimisation.comboBox_config_files.addItems(new_list)
        self.dlg_run_optimisation.comboBox_main_heat_production.clear()
        self.dlg_run_optimisation.comboBox_main_heat_production.addItems(source_main_heats)
        self.dlg_run_optimisation.comboBox_appoint_heat_production.clear()
        self.dlg_run_optimisation.comboBox_appoint_heat_production.addItems(source_appoint_heats)
        self.dlg_run_optimisation.spinBox_energy_unitary_cost.setValue(int(self.optimisation.get_agent_energie_1_value()))
        setup_table_and_from_dict(self.optimisation.set_agent_source_main_heat_name(0),table_main)
        setup_table_and_from_dict(self.optimisation.set_agent_source_appoint_heat_name(0),table_secondary,)
        ## handle spinbox value changed
        self.dlg_run_optimisation.cancelOptimButton.clicked.connect(
            lambda :[
                self.cancel_optimisation()

            ])

        self.dlg_run_optimisation.spinBox_energy_unitary_cost.valueChanged.connect(
            lambda :[
                self.optimisation.set_agent_energie_2_value(100 - self.dlg_run_optimisation.spinBox_energy_unitary_cost.value())

            ])

        self.dlg_run_optimisation.spinBox_energy_unitary_cost.valueChanged.connect(
          lambda :[
              self.optimisation.set_agent_energie_2_value(100 - self.dlg_run_optimisation.spinBox_energy_unitary_cost.value())

          ])
        self.dlg_run_optimisation.comboBox_config_files.currentIndexChanged.connect(
          lambda currentindex : [
              self.optimisation.set_optimistation_path(currentindex)

          ] )
        self.dlg_run_optimisation.comboBox_main_heat_production.currentIndexChanged.connect(
          lambda currentindex : [
              setup_table_and_from_dict(self.optimisation.set_agent_source_main_heat_name(currentindex),table_main)

          ]
      )
        self.dlg_run_optimisation.comboBox_appoint_heat_production.currentIndexChanged.connect(
            lambda currentindex : [
                setup_table_and_from_dict(self.optimisation.set_agent_source_appoint_heat_name(currentindex),table_secondary,)
            ]
        )
        self.dlg_run_optimisation.runOptimistionButton.clicked.connect(
            lambda: [
                self.try_and_run_optimisation(self.dlg_run_optimisation.tableWidgetMainParameter,table_secondary,table_others,self.dlg_run_optimisation.spinBox_energy_unitary_cost.text())
            ]
        )

        self.dlg_run_optimisation.exec_()
    def enable_dlg_run_optimisation_elements(self,value):
        self.dlg_run_optimisation.scrollArea.setEnabled(value)


    def cancel_optimisation(self):
        self.thread1.quit()
        self.thread1.exit()
        self.thread1.terminate()
        self.optimisation_spinner.stop()
        self.enable_dlg_run_optimisation_elements(True)
        self.m_netSession.stop()
        self.cancel_request_optimisation = True
        self.enable_cancel_optim(False)
        self.ui_communication.display_warning_message(self.bar,  "Vous avez annulé l'optimisation !")


        pass
    def try_and_run_optimisation(self,table_main,table_secondary,table_others,coverage_rate):
        self.cancel_request_optimisation = False

        if self.optimisation.is_config_set_up() is True:
            self.send_request(self.optimisation.run_optimisation(table_main,table_secondary,table_others,coverage_rate))
        else:
            self.ui_communication.display_warning_message(self.bar,  "Vous devez selectionner une configuration")

    def send_request(self,payload):
        self.enable_dlg_run_optimisation_elements(False)
        self.optimisation_spinner.start()
        self.enable_cancel_optim(True)
        self.ui_communication.display_information_message(self.bar,"Veuillez attendre s'il vous plaît!")
        task =  HOST + '/solver/tasks/'
        data_str = json.dumps(payload )
        #print(" original payload ", data_str)

        http = Networking()

        self.m_netReply = http.post(task,data_str,self.m_netAccessManager)
        self.m_netReply.finished.connect(self.readData)
        self.m_netReply.error.connect(self.requesterr)

        # Display result
    def readData(self):
        recvData = self.m_netReply.readAll()
        data = str(bytes(recvData.data()), encoding="utf-8")
        #print('data',data)
        #print('recvData',recvData)
        try:
            result = json.loads(data)
            self.onSuccess(result)
        except Exception as err:
            self.onFailed(err)

    def onSuccess(self,result):

        task_id = result['task_id']
        self.thread1 = QThread1(task_id)
        self.thread1.finished.connect(lambda: self.on_finished_get_result(task_id))
        self.thread1.start()

    def on_finished_get_result(self,task_id):
        if self.cancel_request_optimisation == False:
            try:
                self.optimisation_spinner.stop()
                self.enable_dlg_run_optimisation_elements(True)
                self.enable_cancel_optim(False)


                # Result now available
                response = requests.get(HOST + '/solver/tasks/{}/result'.format(task_id))
                result = response.json()
                #print("result",result)
                #print(" jsonresult",json.dumps(result))
                if result['status'] == 'solver_error':
                    self.ui_communication.display_simple_success_message(self.bar,  "l'optimisation s'est terminée avec une erreur")
                elif result['status'] == 'no_solution_found':
                    self.ui_communication.display_simple_success_message(self.bar,  " l'optimisation s'est bien passé ! Mais aucun résultat n'a été trouvé. ")
                else:
                    self.ui_communication.display_simple_success_message(self.bar,  "l'optimisation s'est bien passée!")
                    #print("self.optimisation.get_current_config_path", self.optimisation.get_current_config_path())
                    content =  retrieve_content_file(self.optimisation.get_current_config_path())
                    new_content = write_result_to_optim_content(content,result)
                    #print ("new_content ",new_content)
                    new_content = json.dumps(new_content)
                    #print ("dumps new_content ",new_content)
                    name_file,path =self.optimisation.write_to_file_with_path(new_content)
            except:
                pass


    def onFailed(self,err):
        print("err",err)

    def requesterr(self,err):
        self.optimisation_spinner.stop()
        self.enable_dlg_run_optimisation_elements(True)
        self.ui_communication.display_error_message(self.bar, "Une erreur est survenu lors de la tentative d'optimisation, veuillez rééssayer plus tard..")
        print(err)

    def reload_comboBox_config_files(self):
        self.dlg_run_optimisation.comboBox_config_files.clear()
        self.optimisation.update()
        self.lancer_optimisation_fenetre()

    def generate_reseau(self):
        self.ui_communication.display_information_message(self.iface.messageBar(),  "Le réseaux complet va être généré")
        """Run method that performs all the real work"""
        # show the dialog
        saver = Saver()
        dst = saver.get_value_with_key('distance_value','')
        self.dlg.distance.setText(dst)
        conso = saver.get_value_with_key('consommation_value','')
        self.dlg.consommation.setText(conso)
        self.dlg.show()
        # Run the dialog event loop
        result = self.dlg.exec_()
        # See if OK was pressed
        if result:
            # retrieve input from user
            can_run = True
            try:
                dst = int(self.dlg.distance.text())
                saver.save_value_with_key('distance_value',self.dlg.distance.text())
            except:
                can_run = False
                self.ui_communication.display_warning_message(self.iface.messageBar(), "Vous devez entrez une distance")
            try:
                conso = int(self.dlg.consommation.text())
                saver.save_value_with_key('consommation_value',self.dlg.consommation.text())
            except:
                can_run = False
                self.ui_communication.display_warning_message(self.iface.messageBar(),  "Vous devez entrez une consommation minimum")
            if not self.feeder:
                can_run = False
                self.ui_communication.display_warning_message(self.iface.messageBar(),  "Vous devez importer un feeder")
                self.select_input_shp_feeder()
            if not self.sources:
                can_run = False
                self.ui_communication.display_warning_message(self.iface.messageBar(),"Vous devez importer des sources")
                self.select_input_shp_sources()
            if not self.consommation:
                can_run = False
                self.ui_communication.display_warning_message(self.iface.messageBar(), "Vous devez importer une consommation")
                self.select_input_shp_consomation()
            if not self.output_path:
                can_run = False
                self.ui_communication.display_warning_message(self.iface.messageBar(),"Vous devez selectionner le répertoire de sortie")
                self.output_path = self.select_output_path()

            # the user must have fill the information before we go further
            if can_run == True:



                input_conso_min = conso
                input_distance_buffer = dst # to be type by the user
                output_path =  self.output_path
                secondaire = Secondaire(input_distance_buffer,input_conso_min,self.consommation.get_path(),self.feeder.get_path(),output_path)
                buffer,multiparttosingleparts,feeder_seg, distancetonearesthublinetohub, extendlines = secondaire.generate()
                path_json_ready = False
                path_json = None
                while path_json_ready != True:
                    path_json = self.select_output_path_json()
                    if path_json != None and path_json[0]:
                        path_json_ready = True




                load_simple_shapefile(buffer,"buffer")
                load_simple_shapefile(multiparttosingleparts,"consommations_sel")
                load_simple_shapefile(feeder_seg,"feeder_seg")
                load_simple_shapefile(distancetonearesthublinetohub,"secondaire")
                # Handle the Graph
                graph = Graph(feeder_seg,distancetonearesthublinetohub,multiparttosingleparts,self.sources.get_path())
                self.graph = graph
                config_json = self.graph.process_graph()



                self.ui_communication.display_simple_success_message(self.iface.messageBar(),  "Le réseau complet a été généré.")
                message_error = "Attention les données d'entrée (consommations, Feeder, et source) n'ont pas le même système de coordonnées projetées. Le réseau généré ne donnera pas de résultats cohérents."

                if self.feeder.get_crs() != self.sources.get_crs():

                    self.ui_communication.display_error_message(self.iface.messageBar(),message_error)
                if self.consommation.get_crs() != self.sources.get_crs():
                    self.ui_communication.display_error_message(self.iface.messageBar(),message_error)
                if self.consommation.get_crs() != self.feeder.get_crs():
                    self.ui_communication.display_error_message(self.iface.messageBar(),message_error)

            # create json payload
                sources = []
                #print("config_json", config_json)
                for s in config_json.keys():
                    sources.append(retrieveJson(config_json[s]))
                import json

                saver = Saver()
                #consommation citation
                sources = write_result_to_content(sources,self.graph.get_longueur(), self.graph.get_power_tot(),self.graph.get_consumption_tot())
                sources = json.dumps(sources)
                name_file, path = write_to_file_with_path(path_json[0],''.join(sources))
                new_conf_file = [{"name":name_file,"path":path}]
                configuration_list = saver.get_value_with_key('network_configuration_list',[{"name":"title","path":"no_path"} ])
                configuration_list += new_conf_file
                new_entry = configuration_list
                saver.save_value_with_key('network_configuration_list',new_entry)

            else:
                self.generate_reseau()

def errorCatcher( ):
    print ("WMS Error caught! Details")
